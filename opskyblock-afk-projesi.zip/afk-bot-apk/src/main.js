import { NodeJS } from 'capacitor-nodejs'
import { registerPlugin } from '@capacitor/core'

// Yapimci: ShibaBey
// Android'e ozel kucuk eklenti (android-ekler/ icindeki Java dosyalari): on plan servisi + pil izni
const KeepAlive = registerPlugin('KeepAlive')

const $ = (id) => document.getElementById(id)
const el = {
  levha: document.querySelector('.levha'),
  asama: $('asama'), hesapSatiri: $('hesapSatiri'),
  alici: $('alici'), otomatik: $('otomatik'), altin: $('altin'), altinUygula: $('altinUygula'),
  liste: $('hesapListesi'), ekle: $('ekle'),
  hata: $('hata'), baslat: $('baslat'), durdur: $('durdur'),
  takas: $('takas'), esyaTrade: $('esyaTrade'), gunlukOdul: $('gunlukOdul'), depo: $('depo'), skor: $('skor'), pil: $('pil'), depolama: $('depolama'), sil: $('sil'), gunluk: $('gunluk')
}
const tg = {
  acik: $('tgAcik'), token: $('tgToken'), chat: $('tgChat'), kaydet: $('tgKaydet'), test: $('tgTest'),
  olaylar: Array.from(document.querySelectorAll('[data-olay]'))
}

// Node tarafindan gelen asama yazilari (ASCII) -> Turkce gosterim
const ASAMA = {
  'Durdu': 'Durdu',
  'Sirada': 'Sırada',
  'Oyundan cikarildi': 'Oyundan çıkarıldı',
  'Altin atiyor': 'Altın atıyor',
  'Baslatiliyor': 'Başlatılıyor',
  'Baglaniyor': 'Bağlanıyor',
  'Yeniden baglaniyor': 'Yeniden bağlanıyor',
  'Sunucu bakimda': 'Sunucu bakımda',
  'Ag protokolu hatasi': 'Ağ protokolü hatası',
  'Baglanti kesildi': 'Bağlantı kesildi',
  'Giris yapiliyor': 'Giriş yapılıyor',
  "OpSkyblock'a geciliyor": "OpSkyblock'a geçiliyor",
  "Warp AFK'ya gidiliyor": "Warp AFK'ya gidiliyor",
  "Beacon'a gidiliyor": "Beacon'a gidiliyor",
  'Beacon menusu acilamadi': 'Beacon menüsü açılamadı',
  'AFK noktasina gidilemedi': 'AFK noktasına gidilemedi',
  'AFK bolgesinde': 'AFK bölgesinde',
  'Gunluk odul kontrol ediliyor': 'Günlük ödül kontrol ediliyor',
  'Ada sandigina esya konuyor': 'Ada sandığına eşya konuyor',
  'AFK bolgesine donuluyor': 'AFK bölgesine dönülüyor',
  'Dinar gonderiliyor': 'Dinar gönderiliyor'
}
const asamaYazisi = (a) => ASAMA[a] || a || ''

let calisiyor = false
let servisAcik = false
const satirlar = []   // { kok, ad, sifre, durum, kaldir, no, kayitliSifre }

// Yerel saat dilimini Node tarafina bildir (gunluk odul tarihi icin). UTC+3 icin -180 gonderilir.
function saatGonder() { try { gonder('saat', { sapma: new Date().getTimezoneOffset() }) } catch (e) {} }

function gonder(eventName, ...args) {
  NodeJS.send({ eventName, args })
}

function hataGoster(mesaj) {
  el.hata.textContent = mesaj || ''
  el.hata.hidden = !mesaj
}

function logEkle(satir) {
  const alta = el.gunluk.scrollTop + el.gunluk.clientHeight >= el.gunluk.scrollHeight - 30
  el.gunluk.textContent += (el.gunluk.textContent ? '\n' : '') + satir
  if (el.gunluk.textContent.length > 30000) el.gunluk.textContent = el.gunluk.textContent.slice(-22000)
  if (alta) el.gunluk.scrollTop = el.gunluk.scrollHeight
}

async function servisAyarla(ac) {
  if (ac === servisAcik) return
  try {
    if (ac) await KeepAlive.start()
    else await KeepAlive.stop()
    servisAcik = ac
  } catch (e) {
    logEkle('(Arka plan servisi ' + (ac ? 'açılamadı' : 'kapatılamadı') + ': ' + (e && e.message ? e.message : e) + ')')
  }
}

// ---------- AFK hesap satirlari ----------
function satirEkle(ad, kayitliSifre) {
  const kok = document.createElement('div')
  kok.className = 'hesap'

  const ust = document.createElement('div')
  ust.className = 'hesap-ust'
  const no = document.createElement('span')
  no.className = 'hesap-no'
  const durum = document.createElement('span')
  durum.className = 'hesap-asama'
  const kaldir = document.createElement('button')
  kaldir.type = 'button'
  kaldir.className = 'hesap-kaldir'
  kaldir.textContent = 'Kaldır'
  const oyun = document.createElement('button')
  oyun.type = 'button'
  oyun.className = 'hesap-oyun'
  oyun.textContent = 'Oyundan çıkar'
  ust.appendChild(no)
  ust.appendChild(durum)
  ust.appendChild(oyun)
  ust.appendChild(kaldir)

  const adKutusu = document.createElement('input')
  adKutusu.type = 'text'
  adKutusu.maxLength = 16
  adKutusu.autocomplete = 'off'
  adKutusu.autocapitalize = 'off'
  adKutusu.spellcheck = false
  adKutusu.placeholder = 'Kullanıcı adı'
  adKutusu.value = ad || ''

  const sifreKutusu = document.createElement('input')
  sifreKutusu.type = 'password'
  sifreKutusu.maxLength = 64
  sifreKutusu.autocomplete = 'off'

  // sohbet / komut satiri (hesap calisirken kullanilir)
  const sohbetSatiri = document.createElement('div')
  sohbetSatiri.className = 'sohbet-satiri'
  const sohbetKutusu = document.createElement('input')
  sohbetKutusu.type = 'text'
  sohbetKutusu.maxLength = 256
  sohbetKutusu.autocomplete = 'off'
  sohbetKutusu.autocapitalize = 'off'
  sohbetKutusu.spellcheck = false
  sohbetKutusu.placeholder = 'Sohbete yaz / komut (/spawn)'
  const sohbetGonder = document.createElement('button')
  sohbetGonder.type = 'button'
  sohbetGonder.className = 'sohbet-gonder'
  sohbetGonder.textContent = 'Gönder'
  sohbetSatiri.appendChild(sohbetKutusu)
  sohbetSatiri.appendChild(sohbetGonder)

  kok.appendChild(ust)
  kok.appendChild(adKutusu)
  kok.appendChild(sifreKutusu)
  kok.appendChild(sohbetSatiri)

  const s = { kok, no, durum, kaldir, oyun, oturumVar: false, cikarildi: false, ad: adKutusu, sifre: sifreKutusu, sohbet: sohbetKutusu, sohbetGonder, hesapCalisiyor: false, kayitliSifre: !!kayitliSifre }
  sifreKutusu.placeholder = s.kayitliSifre ? 'Kayıtlı şifre kullanılacak' : 'Şifre'
  adKutusu.addEventListener('input', butonlariGuncelle)
  sifreKutusu.addEventListener('input', butonlariGuncelle)
  kaldir.addEventListener('click', () => satirKaldir(s))
  oyun.addEventListener('click', () => {
    if (!calisiyor || !s.oturumVar) return
    gonder('oyun', { kullanici: adKutusu.value.trim(), islem: s.cikarildi ? 'sok' : 'cikar' })
  })
  const mesajGonder = () => {
    const mesaj = sohbetKutusu.value.trim()
    if (!mesaj || sohbetKutusu.disabled) return
    gonder('sohbet', { kullanici: adKutusu.value.trim(), mesaj })
    sohbetKutusu.value = ''
  }
  sohbetGonder.addEventListener('click', mesajGonder)
  sohbetKutusu.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); mesajGonder() } })
  satirlar.push(s)
  el.liste.appendChild(kok)
  numaralariGuncelle()
  butonlariGuncelle()
  return s
}

function satirKaldir(s) {
  if (calisiyor) return
  if (satirlar.length <= 1) {   // son satir silinmez, bosaltilir
    s.ad.value = ''
    s.sifre.value = ''
    s.kayitliSifre = false
    s.sifre.placeholder = 'Şifre'
  } else {
    satirlar.splice(satirlar.indexOf(s), 1)
    s.kok.remove()
  }
  numaralariGuncelle()
  butonlariGuncelle()
}

function numaralariGuncelle() {
  satirlar.forEach((s, i) => { s.no.textContent = 'Hesap ' + (i + 1) })
}

function satirlariSunucudanKur(liste) {
  while (satirlar.length) satirlar.pop().kok.remove()
  if (!liste.length) satirEkle('', false)
  else liste.forEach((h) => satirEkle(h.kullanici, h.sifreKayitli))
}

const satirlarBos = () => satirlar.every((s) => !s.ad.value.trim() && !s.sifre.value)

// ---------- Durum ve dugmeler ----------
function butonlariGuncelle() {
  const dolu = satirlar.filter((s) => s.ad.value.trim())
  const hazirHesap = dolu.length > 0 && dolu.every((s) => s.sifre.value || s.kayitliSifre)
  el.baslat.hidden = calisiyor
  el.durdur.hidden = !calisiyor
  el.baslat.disabled = !hazirHesap
  el.takas.disabled = !calisiyor || !el.alici.value.trim()
  el.esyaTrade.disabled = !calisiyor || !el.alici.value.trim()
  el.gunlukOdul.disabled = !calisiyor
  el.depo.disabled = !calisiyor
  el.alici.disabled = calisiyor
  el.otomatik.disabled = calisiyor
  el.ekle.disabled = calisiyor
  for (const s of satirlar) {
    s.ad.disabled = calisiyor
    s.sifre.disabled = calisiyor
    s.kaldir.disabled = calisiyor
    s.oyun.disabled = !(calisiyor && s.oturumVar)
    s.oyun.textContent = s.cikarildi ? 'Oyuna sok' : 'Oyundan çıkar'
    s.oyun.classList.toggle('sok', s.cikarildi)
    const sohbetAcik = calisiyor && s.hesapCalisiyor
    s.sohbet.disabled = !sohbetAcik
    s.sohbetGonder.disabled = !sohbetAcik
  }
}

function durumCiz(d) {
  if (!d) return
  calisiyor = !!d.calisiyor
  const hesaplar = d.hesaplar || []

  if (!calisiyor && satirlarBos()) satirlariSunucudanKur(hesaplar)
  if (d.alici && !el.alici.value) el.alici.value = d.alici
  if (d.altinHesabi && !el.altin.value && document.activeElement !== el.altin) el.altin.value = d.altinHesabi
  if (!calisiyor) el.otomatik.checked = !!d.otomatik

  // satir basina durum ve sifre kayit bilgisi
  for (const s of satirlar) {
    const h = hesaplar.find((x) => x.kullanici.toLowerCase() === s.ad.value.trim().toLowerCase())
    s.oturumVar = !!(h && h.calisiyor)
    s.cikarildi = !!(h && h.calisiyor && h.cikarildi)
    s.hesapCalisiyor = s.oturumVar && !s.cikarildi   // sohbet kutusu sadece oyundaki hesapta acik
    s.durum.textContent = h && h.calisiyor ? asamaYazisi(h.asama) : ''
    if (h) {
      s.kayitliSifre = !!h.sifreKayitli
      s.sifre.placeholder = s.kayitliSifre ? 'Kayıtlı şifre kullanılacak' : 'Şifre'
    }
  }

  // ust ozet
  const calisanlar = hesaplar.filter((h) => h.calisiyor)
  el.levha.classList.toggle('calisiyor', calisiyor)
  el.asama.textContent = calisiyor ? calisanlar.filter((h) => !h.cikarildi).length + ' hesap çalışıyor' : 'Bot Aktif Değil'
  if (calisanlar.length) {
    const sayim = {}
    calisanlar.forEach((h) => { const y = asamaYazisi(h.asama); sayim[y] = (sayim[y] || 0) + 1 })
    el.hesapSatiri.textContent = Object.entries(sayim).map(([y, n]) => y + ': ' + n).join(', ')
  } else {
    el.hesapSatiri.textContent = 'Henüz çalışan hesap yok'
  }

  servisAyarla(calisiyor)
  butonlariGuncelle()
}

// ---------- Telegram ----------
function tgCiz(d) {
  if (!d) return
  tg.acik.checked = !!d.acik
  tg.chat.value = d.chatId || ''
  tg.token.value = ''
  tg.token.placeholder = d.tokenVar ? 'Kayıtlı token kullanılacak' : 'Bot token'
  for (const c of tg.olaylar) c.checked = !!(d.olaylar && d.olaylar[c.dataset.olay])
}
const tgVeri = () => ({
  acik: tg.acik.checked,
  token: tg.token.value.trim(),
  chatId: tg.chat.value.trim(),
  olaylar: Object.fromEntries(tg.olaylar.map((c) => [c.dataset.olay, c.checked]))
})
tg.kaydet.addEventListener('click', () => { hataGoster(''); gonder('telegramKaydet', tgVeri()) })
tg.test.addEventListener('click', () => { hataGoster(''); const v = tgVeri(); gonder('telegramTest', { token: v.token, chatId: v.chatId }) })

// ---------- Olaylar ----------
el.alici.addEventListener('input', butonlariGuncelle)
el.ekle.addEventListener('click', () => {
  if (calisiyor) return
  const s = satirEkle('', false)
  s.ad.focus()
})

el.baslat.addEventListener('click', () => {
  hataGoster('')
  saatGonder()
  const hesaplar = satirlar
    .filter((s) => s.ad.value.trim())
    .map((s) => ({ kullanici: s.ad.value.trim(), sifre: s.sifre.value }))
  gonder('baslat', { hesaplar, alici: el.alici.value.trim(), altinHesabi: el.altin.value.trim(), otomatik: el.otomatik.checked })
  for (const s of satirlar) s.sifre.value = ''
})
el.altinUygula.addEventListener('click', () => { hataGoster(''); gonder('altinHesabi', { kullanici: el.altin.value.trim() }) })
el.durdur.addEventListener('click', () => { hataGoster(''); gonder('durdur') })
el.takas.addEventListener('click', () => gonder('trade'))
el.esyaTrade.addEventListener('click', () => gonder('esyaTrade'))
el.gunlukOdul.addEventListener('click', () => gonder('gunlukOdul'))
el.depo.addEventListener('click', () => gonder('depo'))
el.skor.addEventListener('click', () => gonder('skor'))
el.depolama.addEventListener('click', () => gonder('depolama'))
el.pil.addEventListener('click', async () => {
  try {
    const r = await KeepAlive.pilIzni()
    logEkle('Pil kısıtlaması: ' + (r && r.izinli ? 'kapalı (iyi)' : 'açık, açılan ekranda "Kısıtlama yok" seç'))
  } catch (e) { logEkle('Pil izni ekranı açılamadı') }
})
el.sil.addEventListener('click', () => {
  if (!confirm('Kayıtlı kullanıcı adları ve şifreler silinsin mi? Tüm botlar da durdurulur.')) return
  gonder('sil')
  el.alici.value = ''
  el.altin.value = ''
  satirlariSunucudanKur([])
})

async function basla() {
  satirEkle('', false)
  butonlariGuncelle()
  await NodeJS.whenReady()
  NodeJS.addListener('log', (e) => logEkle(e.args[0]))
  NodeJS.addListener('gecmis', (e) => { el.gunluk.textContent = ''; (e.args[0] || []).forEach(logEkle) })
  NodeJS.addListener('durum', (e) => durumCiz(e.args[0]))
  NodeJS.addListener('hata', (e) => hataGoster(e.args[0]))
  NodeJS.addListener('telegram', (e) => tgCiz(e.args[0]))
  saatGonder()
  setInterval(saatGonder, 300000)   // saat dilimi/yaz saati degisirse guncel kalsin
  gonder('hazir')
}

basla().catch((e) => logEkle('Başlatılamadı: ' + (e && e.message ? e.message : e)))
