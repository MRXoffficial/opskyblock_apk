'use strict'
// AFK Bot - Node tarafi (nodejs-mobile icinde calisir).
// Yapimci: ShibaBey
// Arayuz (WebView) ile 'bridge' uzerinden mesajlasir. Birden cok AFK hesabi ayni anda calisabilir.

const { channel, getDataPath } = require('bridge')
const fs = require('fs')
const path = require('path')
const crypto = require('crypto')
const net = require('net')
const https = require('https')
const mineflayer = require('mineflayer')

// ====== SABIT AYARLAR ======
const A = {
  HOST: 'play.ronemacraft.com',
  PORT: 25565,
  VERSION: '1.20.4',            // sunucu surumu (bos birakirsan otomatik algilanir)
  LOGIN_BEKLEME: 2000,          // girisden kac ms sonra /login
  OYUN_BEKLEME: 10000,        // /login'den kac ms sonra /opskyblock
  OYUN_KOMUTU: '/opskyblock',   // lobiden OpSkyblock'a gecis komutu
  MENU_SONRASI_BEKLEME: 10000,  // /opskyblock'tan sonra /warp afk'a kadar
  ETIKET: 'OpSkyblock',         // Telegram mesajlarinin basina eklenir (iki uygulama ayni botu kullaniyorsa hangisi oldugu anlasilir)
  BAL_KOMUTU: '/bal',           // bakiye sorgulama
  PAY_KOMUTU: '/pay',           // para gonderme: '/pay <alici> <miktar>'
  BAL_ESLESME: /bakiye|balance|para|dinar|money|bal\b/i, // /bal cevabi satirini taniyan anahtar kelimeler
  DINAR_ONDALIK: 0,             // gonderilen tutarin ondalik basamak sayisi (0 = tam sayiya yuvarla/asagi)
  DEPO_ACIK: true,              // envanterdeki spawner / anahtar / etkinlik kemigini ada sandigina koy
  DEPO_KOMUTU: '/is chest',     // "Ada Sandigi" menusunu acan komut
  DEPO_ARALIK: 60 * 1000,       // AFK'daki hesaplar icin envanter kontrolu araligi (1 dakika)
  DEPO_ILK_BEKLEME: 60000,      // AFK noktasina vardiktan sonra ilk kontrole kadar en az bekleme
  DEPO_ESYA_ADLARI: ['spawner'], // anahtarlarla (TRADE_ESYA_ADLARI) birlikte sandiga konacak esyalar
  DEPO_OZEL_ESYALAR: [{ ad: 'bone', isim: /kurt\s+etkinlik/i }], // sadece ozel isimli olanlar: "Kurt Etkinlik Kemigi" (siradan kemige dokunulmaz)
  DEPO_SANDIK_SLOTLARI: [10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34], // "Ada Sandigi" menusunde 21 sandik (dolunca siradakine gecilir)
  DEPO_DOLU_HAFIZA: 30 * 60 * 1000, // dolu cikan sandik bu sure boyunca tekrar denenmez (her dakika 21 sandigi gezmemek icin)
  DEPO_PENCERE_BEKLEME: 10000,  // komut / sandik tiklamasindan sonra pencere acilana kadar en fazla bekleme
  DEPO_TIKLA_ARALIK: 400,       // shift+tiklamalar arasi bekleme
  GUNLUK_ACIK: true,            // gunluk odulu otomatik al
  GUNLUK_KOMUTLAR: ['/günlüködül', '/gunlukodul'],   // sirayla denenir, menuyu acan kullanilir
  GUNLUK_ODUL_ESYA: 'ender_chest',   // alinabilir odulun esyasi (menude yesil blok = alinmis)
  GUNLUK_ALINDI_ESLESME: /lime|green|slime/i,   // alinmis odul esyasinin adi (yesil blok)
  GUNLUK_SLOTLAR: [10, 11, 12, 13, 14, 15, 16], // menudeki gun slotlari (2. satir, soldan saga: 1. gunden 7. gune). null yazarsan tum slotlar taranir
  GUNLUK_BASLAMA_BEKLEME: 5000,      // AFK bolgesine varinca kontrolden once bekleme
  GUNLUK_PENCERE_BEKLEME: 10000,     // komuttan sonra menu acilana kadar en fazla bekleme
  GUNLUK_TIKLA_BEKLEME: 1500,        // menu acildiktan sonra tiklamadan once
  GUNLUK_SONUC_BEKLEME: 3000,        // tiklamadan sonra sonucu degerlendirmeden once
  GUNLUK_MAKS_DENEME: 6,             // ayni gun icinde en fazla deneme (basarisizsa)
  GUNLUK_TEKRAR_ARALIK: 60 * 60 * 1000, // basarisiz denemeler arasi bekleme (sunucu sifirlama saati farkliysa sonra tekrar dener)
  GUNLUK_ZATEN_ESLESME: /zaten|daha önce|daha once|already|yar[ıi]n|tekrar alabilirsin|bekle/i, // sunucu cevabi "bugun zaten alindi" diyorsa
  BEACON_HESAPLAR: [],          // bu hesaplar /warp afk yerine /beacon menusunden feneri kullanir (kucuk harfle yaz). Bos = hepsi /warp afk kullanir
  BEACON_KOMUTU: '/beacon',
  BEACON_SLOT: 10,              // "Yeniden Dogma Fenerlerin" menusunde fenerin slotu (2. satir, 2. sutun = 1*9+1)
  BEACON_PENCERE_BEKLEME: 10000, // /beacon'dan sonra menu acilana kadar en fazla bekleme
  BEACON_TIKLA_BEKLEME: 1500,   // menu acildiktan sonra tiklamadan once
  BEACON_BEKLEME: 10000,        // tiklamadan sonra isinlanma kontrolune kadar
  WARP_KOMUTU: '/warp afk',
  WARP_BEKLEME: 10000,          // /warp afk'tan sonra isinlanma kontrolune kadar (bu surede "oyuncu limiti" mesaji gelirse hemen siradaki komut denenir)
  WARP_KOMUTLARI: ['/warp afk', '/warp afk2', '/warp afk3'],  // dunya oyuncu limitine ulasildiysa sirayla denenir
  WARP_DOLU_ESLESME: /oyuncu\s+limit|player\s+limit|limitine\s+ula/i, // "Dunya oyuncu limitine ulasti." mesajini taniyan kalip
  WARP_TUR_BEKLEME: 20000,      // uc komut da dolu cikarsa yeniden bastan denemeden once bekleme
  WARP_MAKS_TUR: 5,             // uc komutun en fazla kac kez bastan denenecegi
  WARP_TEKRAR: 0,               // 0 = /warp afk sadece bir kez yazilir
  ISINLANMA_ESIK: 5,            // bu kadar blokdan az yer degistirdiyse isinlanma olmadi say
  RESTART_SAAT: '',             // bos = gunluk restart zamanlayicisi kapali. Istersen '06:05' yaz
  BAKIYE_OKU_ZAMAN: 5000,      // /bal yazdiktan sonra cevap icin en fazla bekleme
  TRADE_ADIM_BEKLEME: 5000,    // bakiye okunduktan sonra /pay'e kadar
  TRADE_SONRASI_BEKLEME: 5000, // /pay'den sonra bekleme
  TRADE_SONUC_BEKLEME: 5000,    // /pay cevabini gunluge yazmak icin dinleme suresi
  TRADE_ARALIK: 60000,
  TPA_KOMUTU: '/tpa',                  // trade'den once aliciya isinlanmak icin: '/tpa <alici>'
  TPA_BEKLEME: 10000,                  // /tpa'dan sonra alici 10 sn icinde kabul etmezse trade iptal edilir
  ESYA_TPA_SONRASI_BEKLEME: 5000,      // isinlandiktan sonra /trade yazmadan once bekleme
  ESYA_ONAY_ILK_BEKLEME: 5000,         // trade ekrani acildiktan sonra onay tiklamasina kadar en az bu kadar bekle (trade onay suresi)
  ESYA_ONAY_SONRASI_BEKLEME: 6000,     // onay tiklandiktan sonra /warp afk'ya donmeden once bekleme
  TRADE_KOMUTU: '/trade',              // oyuncu trade istegi: '/trade <alici>'
  TRADE_ONAY_SLOT: 0,                  // trade ekraninda "Takasi Kabul Et" dugmesinin slotu (sol ust = 0)
  TRADE_ONAY_BEKLEME: 1500,            // esyalar konduktan sonra onay tiklamasina kadar bekleme
  TRADE_SOL_SUTUNLAR: [1, 2, 3],       // shift+tikla calismazsa esyalar bu sutunlardaki bos slotlara konur (sutun = slot % 9)
  TRADE_ESYA_ADLARI: ['trail_key', 'trial_key'],   // trade ekranina SADECE bu esyalar konur (minecraft: oneki olmadan)
  TRADE_ESYA_ISIM: /trail[ _-]?key|trial[ _-]?key/i, // surum donusumunde esya adi degisirse gorunen isimden de yakalanir
  TRADE_PENCERE_BEKLEME: 90000,        // /trade'den sonra alici kabul edip trade ekrani acilana kadar en fazla bekleme
  TRADE_HEDEF_SLOTLAR: [],             // [] = once shift+tikla, olmazsa TRADE_SOL_SUTUNLAR'daki bos slotlar. Dolu yazarsan (ornek [10, 11, 12]) dogrudan bu slotlar kullanilir
  TRADE_DOKUM_GIZLE: /glass/i,         // trade ekrani dokumunde (Dolu slotlar) adinda bu gecen esyalar (cam / cam panel) yazdirilmaz
  TRADE_TIKLA_ARALIK: 400,             // trade ekraninda tiklamalar arasi bekleme
  GORUS_MESAFESI: 'tiny',      // sunucudan istenen chunk mesafesi: 'tiny' en az bellek kullanir ('short', 'normal', 'far' daha cok)
  BAKIM_BEKLEME: 5 * 60 * 60 * 1000,  // bakim mesajinda yeniden denemeden once bekleme (5 saat)
  PROTOKOL_BEKLEME: 60000,            // ag protokolu hatasinda bekleme (1 dk)
  KESILDI_BEKLEME: 60000,             // baglanti kesildi durumunda bekleme (1 dk)
  HESAP_ARALIK: 5000,           // bir hesabin islemleri bitince siradaki hesaba gecmeden onceki bekleme
  SIRA_ZAMAN_ASIMI: 4 * 60 * 1000, // bir hesap bu surede bitiremezse (takilirsa) siradaki hesaba gecilir
  ALTIN_ARALIK: 5000,           // altin hesabi: dongu araligi (her 5 sn'de bir /dctakas, /actakas, altin atma)
  ALTIN_KOMUTLAR: ['/dctakas', '/actakas'],  // dongude sirayla yazilan komutlar
  ALTIN_KOMUT_ARA: 1000,        // iki komut arasi bekleme
  ALTIN_ESYA: 'gold_ore',       // yere atilacak esya (altin cevheri)
  ALTIN_ATMA_ARA: 450,          // iki yigin atma arasi bekleme (huni ayni anda tek yigin ceker, bu yuzden 0.4 sn'den uzun)
  ALTIN_BAKIS_PITCH: 0          // atmadan once bakis acisi (radyan): 0 = tam karsiya (yatay), negatif = yukari. Eskiden asagi bakinca esya dibine dusuyordu
}
// ===========================

// ---------- Zaman (Turkiye UTC+3, Intl gerekmez) ----------
function simdi() {
  const d = new Date(Date.now() + 3 * 3600 * 1000)
  const p2 = (n) => String(n).padStart(2, '0')
  return {
    tarih: d.getUTCFullYear() + '-' + p2(d.getUTCMonth() + 1) + '-' + p2(d.getUTCDate()),
    saat: p2(d.getUTCHours()) + ':' + p2(d.getUTCMinutes()),
    saniyeli: p2(d.getUTCHours()) + ':' + p2(d.getUTCMinutes()) + ':' + p2(d.getUTCSeconds()),
    dk: d.getUTCHours() * 60 + d.getUTCMinutes(),
    sn: d.getUTCSeconds()
  }
}

// Restart penceresindeyse (hedeften 5 dk once ile hedef arasi) hedefe kalan ms, degilse 0
function hedefeKalanMs() {
  if (!A.RESTART_SAAT) return 0
  const t = simdi()
  const [hh, mm] = A.RESTART_SAAT.split(':').map(Number)
  const hedefDk = hh * 60 + mm
  if (t.dk >= hedefDk - 5 && t.dk < hedefDk) return ((hedefDk - t.dk) * 60 - t.sn) * 1000
  return 0
}

const bekle = (ms) => new Promise((r) => setTimeout(r, ms))

// ---------- Gunluk (arayuze gonderilir) ----------
const gunluk = []
function log(m, oturum) {
  const s = simdi().saniyeli + '  ' + (oturum ? '[' + oturum.profil.kullanici + '] ' : '') + m
  gunluk.push(s)
  if (gunluk.length > 400) gunluk.shift()
  try { channel.send('log', s) } catch (e) {}
}

// ---------- Kayit (AES-256-GCM, uygulamanin ozel klasorunde) ----------
const dosyaYolu = (ad) => path.join(getDataPath(), ad)

function anahtarAl() {
  const y = dosyaYolu('k.bin')
  try { return fs.readFileSync(y) } catch (e) {
    const k = crypto.randomBytes(32)
    fs.writeFileSync(y, k)
    return k
  }
}

let profilOnbellek = null
let profilYuklendi = false

function profilKaydet(profil) {
  const iv = crypto.randomBytes(12)
  const c = crypto.createCipheriv('aes-256-gcm', anahtarAl(), iv)
  const enc = Buffer.concat([c.update(JSON.stringify(profil), 'utf8'), c.final()])
  fs.writeFileSync(dosyaYolu('a.bin'), JSON.stringify({ iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), v: enc.toString('base64') }))
  profilOnbellek = profil
  profilYuklendi = true
}

// Kayit bicimi: { alici, otomatik, hesaplar: [{ kullanici, sifre }] }. Eski tek hesapli kayitlari da cevirir.
function profilOku() {
  if (profilYuklendi) return profilOnbellek
  let p = null
  try {
    const d = JSON.parse(fs.readFileSync(dosyaYolu('a.bin'), 'utf8'))
    const dc = crypto.createDecipheriv('aes-256-gcm', anahtarAl(), Buffer.from(d.iv, 'base64'))
    dc.setAuthTag(Buffer.from(d.tag, 'base64'))
    p = JSON.parse(Buffer.concat([dc.update(Buffer.from(d.v, 'base64')), dc.final()]).toString('utf8'))
    if (p && !Array.isArray(p.hesaplar) && p.kullanici) p = { alici: p.alici, otomatik: !!p.otomatik, hesaplar: [{ kullanici: p.kullanici, sifre: p.sifre }] }
    if (p && !Array.isArray(p.hesaplar)) p = null
  } catch (e) { p = null }
  profilOnbellek = p
  profilYuklendi = true
  return p
}

function profilSil() {
  try { fs.unlinkSync(dosyaYolu('a.bin')) } catch (e) {}
  profilOnbellek = null
  profilYuklendi = true
}

// ---------- Sifreli kucuk dosya yardimcilari (Telegram ayarlari icin) ----------
function sifreliYaz(ad, nesne) {
  const iv = crypto.randomBytes(12)
  const c = crypto.createCipheriv('aes-256-gcm', anahtarAl(), iv)
  const enc = Buffer.concat([c.update(JSON.stringify(nesne), 'utf8'), c.final()])
  fs.writeFileSync(dosyaYolu(ad), JSON.stringify({ iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), v: enc.toString('base64') }))
}

function sifreliOku(ad) {
  try {
    const d = JSON.parse(fs.readFileSync(dosyaYolu(ad), 'utf8'))
    const dc = crypto.createDecipheriv('aes-256-gcm', anahtarAl(), Buffer.from(d.iv, 'base64'))
    dc.setAuthTag(Buffer.from(d.tag, 'base64'))
    return JSON.parse(Buffer.concat([dc.update(Buffer.from(d.v, 'base64')), dc.final()]).toString('utf8'))
  } catch (e) { return null }
}

// ---------- Telegram bildirimleri ----------
// Olaylar: giris (sunucuya girdi / AFK bolgesinde), kopma (atildi / baglanti koptu), bakim, dinar, trade, sorun, durum (baslatildi / durduruldu)
const TG_OLAYLAR = { giris: true, kopma: true, bakim: true, dinar: true, trade: true, odul: true, depo: true, sorun: true, durum: false }
let tgOnbellek = null

function tgOku() {
  if (tgOnbellek) return tgOnbellek
  const t = sifreliOku('t.bin') || {}
  tgOnbellek = { acik: !!t.acik, token: String(t.token || ''), chatId: String(t.chatId || ''), olaylar: Object.assign({}, TG_OLAYLAR, t.olaylar || {}) }
  return tgOnbellek
}

function tgKaydet(t) { sifreliYaz('t.bin', t); tgOnbellek = t }
function tgSil() { try { fs.unlinkSync(dosyaYolu('t.bin')) } catch (e) {}; tgOnbellek = null }
const tgTemiz = (metin, token) => (token ? String(metin).split(token).join('***') : String(metin))

function tgGonder(t, metin) {
  return new Promise((coz) => {
    let bitti = false
    const bit = (r) => { if (!bitti) { bitti = true; coz(r) } }
    try {
      const govde = JSON.stringify({ chat_id: t.chatId, text: String(metin).slice(0, 3500), disable_web_page_preview: true })
      const istek = https.request({
        hostname: 'api.telegram.org', port: 443, method: 'POST', path: '/bot' + t.token + '/sendMessage', timeout: 15000,
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(govde) }
      }, (yanit) => {
        let veri = ''
        yanit.on('data', (d) => { veri += d; if (veri.length > 20000) yanit.destroy() })
        yanit.on('end', () => {
          let j = null
          try { j = JSON.parse(veri) } catch (e) {}
          if (j && j.ok) return bit({ ok: true })
          bit({ ok: false, hata: (j && j.description) || ('HTTP ' + yanit.statusCode), bekle: j && j.parameters && j.parameters.retry_after })
        })
        yanit.on('error', (e) => bit({ ok: false, hata: e.message }))
      })
      istek.on('timeout', () => { istek.destroy(); bit({ ok: false, hata: 'zaman asimi' }) })
      istek.on('error', (e) => bit({ ok: false, hata: e.message }))
      istek.write(govde)
      istek.end()
    } catch (e) { bit({ ok: false, hata: e.message }) }
  })
}

const tgKuyruk = []
let tgIsliyor = false
let tgBeklemeBitis = 0
let tgSonHataLog = 0
const tgSonGonderilen = new Map()

async function tgIsle() {
  if (tgIsliyor) return
  tgIsliyor = true
  try {
    while (tgKuyruk.length) {
      const t = tgOku()
      if (!t.acik || !t.token || !t.chatId) { tgKuyruk.length = 0; break }
      const bekle = tgBeklemeBitis - Date.now()
      if (bekle > 0) await new Promise((r) => setTimeout(r, bekle))
      const r = await tgGonder(t, tgKuyruk.shift())
      if (!r.ok) {
        if (r.bekle) tgBeklemeBitis = Date.now() + r.bekle * 1000
        if (Date.now() - tgSonHataLog > 60000) { tgSonHataLog = Date.now(); log('Telegram bildirimi gonderilemedi: ' + tgTemiz(r.hata, t.token)) }
      }
      await new Promise((r2) => setTimeout(r2, 1200))   // Telegram'a saniyede en fazla ~1 mesaj
    }
  } finally { tgIsliyor = false }
}

function bildir(olay, s, metin) {
  try {
    const t = tgOku()
    if (!t.acik || !t.token || !t.chatId || !t.olaylar[olay]) return
    const ad = s && s.profil ? s.profil.kullanici : ''
    const anahtar = olay + '|' + ad + '|' + metin
    const simdi = Date.now()
    if (simdi - (tgSonGonderilen.get(anahtar) || 0) < 60000) return   // ayni mesaj 60 sn icinde tekrar gitmesin
    tgSonGonderilen.set(anahtar, simdi)
    if (tgSonGonderilen.size > 200) for (const [k, v] of tgSonGonderilen) if (simdi - v > 60000) tgSonGonderilen.delete(k)
    tgKuyruk.push((A.ETIKET ? '[' + A.ETIKET + '] ' : '') + (ad ? '[' + ad + '] ' : '') + metin)
    while (tgKuyruk.length > 30) tgKuyruk.shift()
    tgIsle()
  } catch (e) {}
}

function tgDurumGonder() {
  const t = tgOku()
  try { channel.send('telegram', { acik: t.acik, tokenVar: !!t.token, chatId: t.chatId, olaylar: t.olaylar }) } catch (e) {}
}

const tgTokenGecerli = (x) => /^\d{6,12}:[A-Za-z0-9_-]{30,50}$/.test(x)
const tgChatGecerli = (x) => /^(-?\d{3,20}|@[A-Za-z0-9_]{5,32})$/.test(x)

channel.addListener('telegramKaydet', (veri) => {
  try {
    veri = veri || {}
    const eski = tgOku()
    const tokenGelen = String(veri.token || '').trim()
    const chatId = String(veri.chatId || '').trim()
    if (tokenGelen && !tgTokenGecerli(tokenGelen)) { channel.send('hata', 'Telegram bot token bicimi hatali (ornek: 123456789:ABC...).'); return }
    if (chatId && !tgChatGecerli(chatId)) { channel.send('hata', 'Telegram sohbet ID sadece rakamlardan olusmali (grup ise basinda - olabilir).'); return }
    const token = tokenGelen || eski.token
    const acik = !!veri.acik
    if (acik && (!token || !chatId)) { channel.send('hata', 'Bildirimleri acmak icin bot token ve sohbet ID girilmeli.'); return }
    const olaylar = {}
    for (const k of Object.keys(TG_OLAYLAR)) olaylar[k] = !!(veri.olaylar && veri.olaylar[k])
    tgKaydet({ acik, token, chatId, olaylar })
    log('Telegram ayarlari kaydedildi (' + (acik ? 'acik' : 'kapali') + ')')
    tgDurumGonder()
  } catch (e) { channel.send('hata', 'Telegram ayarlari kaydedilemedi: ' + e.message) }
})

channel.addListener('telegramTest', async (veri) => {
  try {
    veri = veri || {}
    const eski = tgOku()
    const token = String(veri.token || '').trim() || eski.token
    const chatId = String(veri.chatId || '').trim() || eski.chatId
    if (!token || !chatId) { channel.send('hata', 'Test icin bot token ve sohbet ID gir.'); return }
    if (!tgTokenGecerli(token) || !tgChatGecerli(chatId)) { channel.send('hata', 'Telegram bot token ya da sohbet ID bicimi hatali.'); return }
    const r = await tgGonder({ token, chatId }, '✅ AFK Bot: Telegram bildirimi çalışıyor')
    log(r.ok ? 'Telegram test mesaji gonderildi' : 'Telegram test mesaji gonderilemedi: ' + tgTemiz(r.hata, token))
  } catch (e) { log('Telegram test hatasi: ' + e.message) }
})

// ---------- Metin bilesenleri ve skor tablosu ----------
function nbtSade(x) {
  if (x && typeof x === 'object' && typeof x.type === 'string' && 'value' in x) {
    const t = x.type, v = x.value
    if (t === 'compound') { const o = {}; for (const k in v) o[k] = nbtSade(v[k]); return o }
    if (t === 'list') return (v.value || []).map((e) => nbtSade({ type: v.type, value: e }))
    return v
  }
  return x
}

function bilesenMetni(x) {
  if (x === null || x === undefined) return ''
  if (typeof x === 'string') {
    const t = x.trim()
    if (t[0] === '{' || t[0] === '[' || t[0] === '"') { try { return bilesenMetni(JSON.parse(t)) } catch (e) {} }
    return x
  }
  if (typeof x === 'number' || typeof x === 'boolean') return String(x)
  if (Array.isArray(x)) return x.map(bilesenMetni).join('')
  if (typeof x === 'object') {
    if (typeof x.type === 'string' && 'value' in x) return bilesenMetni(nbtSade(x))
    let s = ''
    if (typeof x.text === 'string') s += x.text
    else if (x.text !== undefined) s += bilesenMetni(x.text)
    if (!s && typeof x.translate === 'string') s += x.translate
    if (x.extra !== undefined) s += bilesenMetni(x.extra)
    return s
  }
  return ''
}

function skorTemizle(s) {
  return String(s).replace(/§[0-9a-fk-or]/gi, '').replace(/[\uE000-\uF8FF]/g, '').replace(/\s+/g, ' ').trim()
}

// ---------- Skor tablosu (her hesap icin ayri takip edilir) ----------
function bosSkor() { return { hedefler: {}, sidebar: null, skorlar: {}, takimlar: {}, oyuncuTakim: {} } }

function skorTakipBaslat(s, bot) {
  const c = bot._client
  if (!c) return
  const d = s.skor = bosSkor()
  c.on('scoreboard_objective', (p) => {
    if (p.action === 1) delete d.hedefler[p.name]
    else d.hedefler[p.name] = bilesenMetni(p.displayText)
  })
  c.on('scoreboard_display_objective', (p) => {
    if (p.position === 1 || p.position === 'sidebar') d.sidebar = p.name || null
  })
  c.on('scoreboard_score', (p) => {
    const hedef = p.scoreName !== undefined ? p.scoreName : p.objective_name
    const isim = p.itemName !== undefined ? p.itemName : p.entity_name
    if (hedef === undefined || isim === undefined) return
    if (p.action === 1) { if (d.skorlar[hedef]) delete d.skorlar[hedef][isim]; return }
    if (!d.skorlar[hedef]) d.skorlar[hedef] = {}
    d.skorlar[hedef][isim] = { deger: Number(p.value) || 0, gosterim: (p.display_name !== undefined && p.display_name !== null) ? bilesenMetni(p.display_name) : '' }
  })
  c.on('reset_score', (p) => {
    const hedef = p.scoreName !== undefined ? p.scoreName : (p.objective_name !== undefined ? p.objective_name : p.objectiveName)
    const isim = p.itemName !== undefined ? p.itemName : (p.entity_name !== undefined ? p.entity_name : p.entityName)
    if (isim === undefined) return
    if (hedef !== undefined && hedef !== null) { if (d.skorlar[hedef]) delete d.skorlar[hedef][isim] }
    else for (const h in d.skorlar) delete d.skorlar[h][isim]
  })
  const takimIsleyici = (p) => {
    const ad = p.team
    if (!ad) return
    const mod = typeof p.mode === 'number' ? ['add', 'remove', 'change', 'join', 'leave'][p.mode] : p.mode
    const oyuncular = Array.isArray(p.players) ? p.players : []
    if (mod === 'remove') {
      const t = d.takimlar[ad]
      if (t) t.oyuncular.forEach((o) => { delete d.oyuncuTakim[o] })
      delete d.takimlar[ad]
      return
    }
    let t = d.takimlar[ad]
    if (!t) t = d.takimlar[ad] = { prefix: '', suffix: '', oyuncular: [] }
    if (mod === 'add' || mod === 'change') { t.prefix = bilesenMetni(p.prefix); t.suffix = bilesenMetni(p.suffix) }
    if (mod === 'add' || mod === 'join') oyuncular.forEach((o) => { if (!t.oyuncular.includes(o)) t.oyuncular.push(o); d.oyuncuTakim[o] = ad })
    if (mod === 'leave') oyuncular.forEach((o) => { t.oyuncular = t.oyuncular.filter((x) => x !== o); delete d.oyuncuTakim[o] })
  }
  c.on('teams', takimIsleyici)
  c.on('scoreboard_team', takimIsleyici)
}

function skorSatirlari(s) {
  const d = s.skor
  const hedef = d.sidebar
  if (!hedef) return null
  const ogeler = Object.entries(d.skorlar[hedef] || {}).sort((a, b) => b[1].deger - a[1].deger)
  const satirlar = []
  for (const [isim, o] of ogeler) {
    let metin
    if (o.gosterim) metin = o.gosterim
    else {
      const t = d.takimlar[d.oyuncuTakim[isim]]
      metin = (t ? t.prefix : '') + isim + (t ? t.suffix : '')
    }
    const temiz = skorTemizle(metin)
    if (temiz) satirlar.push(temiz)
  }
  return { baslik: skorTemizle(d.hedefler[hedef] || hedef), satirlar }
}

function skorYazdir(s) {
  const t = skorSatirlari(s)
  if (!t) { log('Skor tablosu henuz gelmedi (oyuna gectikten sonra dene)', s); return }
  log('Skor tablosu: ' + t.baslik, s)
  t.satirlar.forEach((l) => log('   ' + l, s))
}

// ---------- Sayi cevirme (32.7K -> 32700) ----------
const KUCUK_HARF = { 'ᴀ': 'A', 'ʙ': 'B', 'ᴄ': 'C', 'ᴅ': 'D', 'ᴇ': 'E', 'ꜰ': 'F', 'ɢ': 'G', 'ʜ': 'H', 'ɪ': 'I', 'ᴊ': 'J', 'ᴋ': 'K', 'ʟ': 'L', 'ᴍ': 'M', 'ɴ': 'N', 'ᴏ': 'O', 'ᴘ': 'P', 'ǫ': 'Q', 'ʀ': 'R', 'ꜱ': 'S', 'ᴛ': 'T', 'ᴜ': 'U', 'ᴠ': 'V', 'ᴡ': 'W', 'ʏ': 'Y', 'ᴢ': 'Z', 'ı': 'I', 'İ': 'I', 'Ü': 'U', 'ü': 'U', 'Ö': 'O', 'ö': 'O', 'Ç': 'C', 'ç': 'C', 'Ş': 'S', 'ş': 'S', 'Ğ': 'G', 'ğ': 'G' }
const BIRIMLER = { '': 1, K: 1e3, M: 1e6, B: 1e9, T: 1e12 }

function duzYazi(s) {
  return String(s).split('').map((c) => KUCUK_HARF[c] || c).join('').toUpperCase()
}

function kisaSayiCoz(metin) {
  const m = String(metin).trim().match(/^([\d.,]+)\s*([A-Z]*)$/)
  if (!m) return null
  const birim = m[2]
  if (!(birim in BIRIMLER)) return null
  const sayi = birim ? m[1].replace(',', '.') : m[1].replace(/[.,]/g, '')
  const v = Number(sayi)
  if (!isFinite(v)) return null
  return Math.round(v * BIRIMLER[birim])
}

function skorDegeri(s, anahtar) {
  const t = skorSatirlari(s)
  if (!t) return null
  const a = duzYazi(anahtar)
  for (const satir of t.satirlar) {
    const d = duzYazi(satir)
    const i = d.indexOf(a)
    if (i < 0) continue
    const kalan = d.slice(i + a.length).replace(/^[\s:]+/, '')
    const sayi = kisaSayiCoz(kalan)
    if (sayi !== null) return { satir, kalan, sayi }
  }
  return null
}

// ---------- Oturumlar (her AFK hesabi icin bir tane) ----------
let elleDurduruldu = false   // kullanici Durdur'a bastiysa uygulama yeniden acilana kadar otomatik baslatma yapma
const oturumlar = new Map()  // kucuk harfli kullanici adi -> oturum

function canli(s, bot) { return !!s && s.calisiyor && s.bot === bot && (!!bot.entity || !!s.girisYapildi) }

function asamaYaz(s, asama) {
  s.asama = asama
  durumGonder()
}

function durumGonder() {
  const k = profilOku()
  const liste = ((k && k.hesaplar) || []).map((h) => {
    const s = oturumlar.get(h.kullanici.toLowerCase())
    return { kullanici: h.kullanici, sifreKayitli: !!h.sifre, calisiyor: !!(s && s.calisiyor), cikarildi: !!(s && s.cikarildi), asama: s ? s.asama : 'Durdu' }
  })
  for (const s of oturumlar.values()) {
    if (!liste.some((h) => h.kullanici.toLowerCase() === s.profil.kullanici.toLowerCase())) liste.push({ kullanici: s.profil.kullanici, sifreKayitli: true, calisiyor: s.calisiyor, cikarildi: !!s.cikarildi, asama: s.asama })
  }
  try {
    channel.send('durum', {
      calisiyor: oturumlar.size > 0,
      calisanSayisi: oturumlar.size,
      kayitli: !!k,
      alici: k ? k.alici : '',
      otomatik: k ? !!k.otomatik : false,
      altinHesabi: altinHesabiAl(),
      hesaplar: liste
    })
  } catch (e) {}
}

// ---------- Warp ----------
// /warp afk yazar, WARP_BEKLEME sonra konum degisimini gunluge yazar ve devam eder (yurume yok)
function warpGit(s, bot, deneme, sonra) {
  let sira = 0   // WARP_KOMUTLARI icindeki siradaki komut
  let tur = 0    // uc komutun kacinci turu
  const komutlar = A.WARP_KOMUTLARI
  const dene = () => {
    if (!canli(s, bot)) return
    const komut = komutlar[sira]
    const once = bot.entity ? { x: bot.entity.position.x, y: bot.entity.position.y, z: bot.entity.position.z } : null
    let bitti = false
    let z = null
    const dinle = (m, p) => { if (p !== 'game_info' && A.WARP_DOLU_ESLESME.test(skorTemizle(m))) bitir('dolu', skorTemizle(m)) }
    const bitir = (neden, mesaj) => {
      if (bitti) return
      bitti = true
      clearTimeout(z)
      bot.removeListener('messagestr', dinle)
      if (!canli(s, bot)) return
      if (neden === 'dolu') {
        log(komut + ': dunya oyuncu limitine ulasti (' + mesaj + ')', s)
        sira++
        if (sira < komutlar.length) { log('Siradaki komut deneniyor: ' + komutlar[sira], s); dene(); return }
        tur++
        if (tur >= A.WARP_MAKS_TUR) {
          log('Tum warp komutlari dolu (' + A.WARP_MAKS_TUR + ' tur denendi), vazgecildi', s)
          bildir('sorun', s, '❗ ' + komutlar.join(' / ') + ' hepsi dolu, AFK noktasina gidilemedi')
          sonra(false)
          return
        }
        sira = 0
        log('Tum warp komutlari dolu, ' + (A.WARP_TUR_BEKLEME / 1000) + ' sn sonra bastan denenecek (tur ' + (tur + 1) + '/' + A.WARP_MAKS_TUR + ')', s)
        setTimeout(dene, A.WARP_TUR_BEKLEME)
        return
      }
      // limit mesaji gelmedi: isinlanmayi konumdan kontrol et ve devam et
      let tasindi = true
      if (once && bot.entity) {
        const q = bot.entity.position
        const mesafe = Math.hypot(q.x - once.x, q.y - once.y, q.z - once.z)
        tasindi = mesafe >= A.ISINLANMA_ESIK
        log('Isinlanma kontrolu: ' + mesafe.toFixed(1) + ' blok ' + (tasindi ? '(tamam)' : '(isinlanma gorunmuyor)'), s)
      }
      if (sira > 0) { log('AFK noktasina ' + komut + ' ile gidildi', s); bildir('giris', s, 'ℹ️ ' + komutlar[0] + ' doluydu, ' + komut + ' ile girildi') }
      sonra()
    }
    bot.on('messagestr', dinle)
    try { bot.chat(komut); log(komut + ' gonderildi' + (tur > 0 || sira > 0 ? ' (tur ' + (tur + 1) + ')' : ''), s) } catch (e) {}
    z = setTimeout(() => bitir('sure'), A.WARP_BEKLEME)
  }
  dene()
}

// ---------- Beacon (sadece BEACON_HESAPLAR icindeki hesaplar) ----------
const beaconHesabi = (s) => A.BEACON_HESAPLAR.indexOf(String(s.profil.kullanici).toLowerCase()) !== -1

// /beacon yazar, "Yeniden Dogma Fenerlerin" menusunde BEACON_SLOT'taki feneri tiklar. sonra(true/false): basarili mi
function beaconGit(s, bot, sonra) {
  let bitti = false
  const bit = (ok) => { if (bitti) return; bitti = true; sonra(ok) }
  const once = bot.entity ? { x: bot.entity.position.x, y: bot.entity.position.y, z: bot.entity.position.z } : null
  let zamanAsimi = null
  const f = (win) => {
    clearTimeout(zamanAsimi)
    setTimeout(async () => {
      if (!canli(s, bot)) return
      try {
        const w = bot.currentWindow || win
        const hedef = w.slots[A.BEACON_SLOT]
        if (!hedef) {
          log('Beacon menusunde ' + A.BEACON_SLOT + '. slot bos, tiklanmadi', s)
          bildir('sorun', s, '❗ Beacon menüsünde ' + A.BEACON_SLOT + '. slot boş')
          return bit(false)
        }
        const sonuc = await Promise.race([
          bot.clickWindow(A.BEACON_SLOT, 0, 0).then(() => 'tamam'),
          new Promise((r) => setTimeout(() => r('onay gelmedi'), 4000))
        ])
        log('Beacon slotu ' + A.BEACON_SLOT + ' tiklandi (' + (hedef.displayName || hedef.name) + ') [' + sonuc + ']', s)
      } catch (e) {
        log('Beacon tiklama hatasi: ' + e.message, s)
        bildir('sorun', s, '❗ Beacon tıklama hatası: ' + e.message)
        return bit(false)
      }
      setTimeout(() => {
        if (!canli(s, bot)) return
        if (once && bot.entity) {
          const p = bot.entity.position
          const mesafe = Math.hypot(p.x - once.x, p.y - once.y, p.z - once.z)
          log('Isinlanma kontrolu: ' + mesafe.toFixed(1) + ' blok ' + (mesafe >= A.ISINLANMA_ESIK ? '(tamam)' : '(isinlanma gorunmuyor)'), s)
        }
        bit(true)
      }, A.BEACON_BEKLEME)
    }, A.BEACON_TIKLA_BEKLEME)
  }
  bot.once('windowOpen', f)
  zamanAsimi = setTimeout(() => {
    bot.removeListener('windowOpen', f)
    log('Beacon menusu acilmadi (' + (A.BEACON_PENCERE_BEKLEME / 1000) + ' sn)', s)
    bildir('sorun', s, '❗ Beacon menüsü açılmadı')
    bit(false)
  }, A.BEACON_PENCERE_BEKLEME)
  try { bot.chat(A.BEACON_KOMUTU); log(A.BEACON_KOMUTU + ' gonderildi', s) } catch (e) {}
}

// AFK bolgesine git: BEACON_HESAPLAR'daki hesaplar /beacon, digerleri /warp afk kullanir
function afkaGit(s, bot, sonra) {
  if (beaconHesabi(s)) beaconGit(s, bot, sonra)
  else warpGit(s, bot, 0, sonra)
}
// ---------- /Beacon ----------

// ---------- Dinar gonderimi (/bal ile bakiye, /pay ile gonder) ----------
// Sohbet satirlarini ms kadar toplar; erken(satir) true donerse hemen biter
function sohbetTopla(bot, ms, erken) {
  return new Promise((coz) => {
    const satirlar = []
    let bitti = false
    let z = null
    const dinle = (m, p) => {
      if (p === 'game_info') return
      const t = skorTemizle(m)
      if (!t) return
      satirlar.push(t)
      if (erken && erken(t)) bitir()
    }
    const bitir = () => {
      if (bitti) return
      bitti = true
      clearTimeout(z)
      bot.removeListener('messagestr', dinle)
      coz(satirlar)
    }
    z = setTimeout(bitir, ms)
    bot.on('messagestr', dinle)
  })
}

// Para metnini sayiya cevirir: "1.250" -> 1250, "1,234.56" -> 1234.56, "1.234,56" -> 1234.56, "1.2" + M -> 1200000
function paraSayisi(str, sonek) {
  let t = String(str).replace(/[.,]+$/, '')
  const nokta = (t.match(/\./g) || []).length
  const virgul = (t.match(/,/g) || []).length
  let tam = t
  let ondalik = ''
  if (nokta && virgul) {
    const son = Math.max(t.lastIndexOf('.'), t.lastIndexOf(','))
    ondalik = t.slice(son + 1)
    tam = t.slice(0, son)
  } else if (nokta + virgul === 1) {
    const ayir = nokta ? '.' : ','
    const [x, y] = t.split(ayir)
    if (y.length === 3 && !sonek) tam = x + y   // "1.234" binlik ayraci
    else { tam = x; ondalik = y }                // "12.5" / "1.2M" ondalik
  }
  tam = tam.replace(/[.,]/g, '')
  let v = Number(tam + (ondalik ? '.' + ondalik : ''))
  if (!isFinite(v)) return null
  const k = { K: 1e3, M: 1e6, B: 1e9, T: 1e12 }[String(sonek || '').toUpperCase()]
  if (k) v *= k
  return v
}

// "Bakiye: 1.250 Dinar", "Balance: $1,234.56", "Para: 1.2M" gibi /bal satirlarindan tutari cikarir (yoksa null)
function paraMiktari(satir) {
  if (!A.BAL_ESLESME.test(satir)) return null
  const m = satir.match(/(\d[\d.,]*)\s*([KMBTkmbt])?(?![A-Za-z])/)
  return m ? paraSayisi(m[1], m[2]) : null
}

async function bakiyeOku(s, bot) {
  const toplama = sohbetTopla(bot, A.BAKIYE_OKU_ZAMAN, (t) => paraMiktari(t) !== null)
  bot.chat(A.BAL_KOMUTU)
  log(A.BAL_KOMUTU + ' gonderildi, cevap bekleniyor', s)
  const satirlar = await toplama
  for (const t of satirlar) {
    const v = paraMiktari(t)
    if (v !== null) { log(A.BAL_KOMUTU + ' cevabi: ' + t, s); return v }
  }
  log(A.BAL_KOMUTU + ' cevabindan bakiye okunamadi. Gelen satirlar: ' + (satirlar.length ? satirlar.slice(0, 6).join(' | ') : '(hic mesaj gelmedi)'), s)
  return null
}

async function tradeAfkaDon(s, bot) {
  if (!canli(s, bot)) { log('AFK donus iptal: bot sunucuda degil', s); return }
  try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow) } catch (e) {}
  // /tpa kullanilmadigi icin bot yerinden ayrilmaz, tekrar warp gerekmez
  log('Dinar islemi bitti', s)
  asamaYaz(s, 'AFK bolgesinde')
}

// Ayni anda yalnizca tek hesap takas yapar (alici hesap ayni anda iki takasta olamaz); digerleri sirada bekler.
let tradeKuyruk = Promise.resolve()
let tradeKuyrukSayisi = 0

function tradeIste(s, bot, kaynak) {
  if (s.altinHazir) { log('Takas atlandi: altin hesabi AFK noktasina gitmiyor', s); return }
  if (!s.profil.alici) { log('Takas yapilmadi: dinar alacak hesap girilmemis', s); return }
  if (!canli(s, bot)) { log('Takas yapilamadi: bot sunucuda degil', s); return }
  if (s.tradeMesgul || s.tradeSirada) { log('Takas zaten suruyor ya da sirada', s); return }
  const gecen = Date.now() - s.sonTradeZamani
  if (gecen < A.TRADE_ARALIK) { log('Takas cok sik istendi, ' + Math.ceil((A.TRADE_ARALIK - gecen) / 1000) + ' sn sonra tekrar dene', s); return }
  s.tradeSirada = true
  if (tradeKuyrukSayisi > 0) log('Takas sirada: onunde ' + tradeKuyrukSayisi + ' hesap var (ayni anda tek takas yapilir)', s)
  tradeKuyrukSayisi++
  tradeKuyruk = tradeKuyruk
    .then(() => tradeCalistir(s, bot, kaynak))
    .catch(() => {})
    .then(() => { tradeKuyrukSayisi-- })
}

async function tradeCalistir(s, bot, kaynak) {
  s.tradeSirada = false
  if (!s.profil.alici) return
  if (!canli(s, bot)) { log('Dinar gonderilemedi: bot sunucuda degil', s); return }
  const alici = s.profil.alici
  s.tradeMesgul = true
  s.sonTradeZamani = Date.now()
  try {
    asamaYaz(s, 'Dinar gonderiliyor')
    log('DINAR gonderimi basladi (' + kaynak + ') -> alici: ' + alici, s)
    const bakiye = await bakiyeOku(s, bot)
    if (!canli(s, bot)) return
    const kat = Math.pow(10, A.DINAR_ONDALIK)
    const tutar = bakiye === null ? 0 : Math.floor(bakiye * kat) / kat
    if (!tutar || tutar <= 0) { log('DINAR: bakiye okunamadi ya da 0, gonderim iptal', s); bildir('sorun', s, '❗ Dinar bakiyesi okunamadı ya da 0, gönderim iptal'); return }
    const miktarYazi = tutar.toFixed(A.DINAR_ONDALIK)
    log('DINAR bakiyesi: ' + miktarYazi, s)
    await bekle(A.TRADE_ADIM_BEKLEME)
    if (!canli(s, bot)) return
    const sonuc = sohbetTopla(bot, A.TRADE_SONUC_BEKLEME)
    bot.chat(A.PAY_KOMUTU + ' ' + alici + ' ' + miktarYazi)
    log(A.PAY_KOMUTU + ' ' + alici + ' ' + miktarYazi + ' gonderildi', s)
    const cevap = await sonuc
    cevap.slice(0, 4).forEach((t) => log('Sunucu: ' + t, s))
    bildir('dinar', s, '⭐ ' + miktarYazi + ' dinar → ' + alici + ' (' + A.PAY_KOMUTU + ' gönderildi)' + (cevap.length ? '\nSunucu: ' + cevap.slice(0, 2).join(' | ') : ''))
  } catch (e) {
    log('DINAR hata: ' + e.message, s)
    bildir('sorun', s, '❗ Dinar hatası: ' + e.message)
  } finally {
    try { await tradeAfkaDon(s, bot) } catch (e) { log('AFK donus hatasi: ' + e.message, s) }
    s.tradeMesgul = false
  }
}

// Ozel mesaj "<alici> ... trade" ise takasi baslatir (sadece alici hesaptan)
function tradeMesajKontrol(s, bot, msg) {
  if (!s.profil.alici) return
  const temiz = skorTemizle(msg)
  if (!/trade/i.test(temiz)) return
  const ad = s.profil.alici.replace(/[^A-Za-z0-9_]/g, '')
  const uygun = new RegExp('^[^A-Za-z0-9_]*' + ad + '(?![A-Za-z0-9_])', 'i').test(temiz) && /\btrade\s*$/i.test(temiz)
  if (uygun) { log('Takas mesaji alindi: ' + temiz, s); tradeIste(s, bot, 'mesaj') }
}

// ---------- Baglanti ve AFK dongusu ----------
function prisonAkisi(s, bot, kaynak) {
  if (!canli(s, bot)) { girisSirasiBitir(s, 'bot sunucuda degil, siradaki hesaba geciliyor'); return }
  if (Date.now() - s.sonAkisZamani < 120000) { girisSirasiBitir(s, 'akis zaten calisti, siradaki hesaba geciliyor'); return }
  s.sonAkisZamani = Date.now()
  s.afkta = false
  s.altinHazir = false
  log('OpSkyblock akisi basladi (' + kaynak + ')', s)
  asamaYaz(s, 'OpSkyblock\'a geciliyor')
  try {
    bot.chat(A.OYUN_KOMUTU)
    log(A.OYUN_KOMUTU + ' gonderildi', s)
  } catch (e) {
    log(A.OYUN_KOMUTU + ' gonderilemedi: ' + e.message, s)
    bildir('sorun', s, '❗ ' + A.OYUN_KOMUTU + ' gönderilemedi')
    girisSirasiBitir(s, 'siradaki hesaba geciliyor')
    return
  }
  setTimeout(() => {
    if (!canli(s, bot)) { girisSirasiBitir(s, 'bot sunucuda degil, siradaki hesaba geciliyor'); return }
    if (altinHesabiAl().toLowerCase() === String(s.profil.kullanici).toLowerCase()) {
      // altin hesabi AFK bolgesine gitmez: oyunda kalir, altin dongusu burada calisir
      s.altinHazir = true
      s.afktaZamani = Date.now()   // /is chest kontrolu icin ilk bekleme bundan sayilir
      asamaYaz(s, 'Altin atiyor')
      log('Altin hesabi: AFK noktasina gidilmiyor, ' + A.ALTIN_KOMUTLAR.join(' + ') + ' yazilip ' + A.ALTIN_ESYA + ' atilacak (gunluk odul ve /is chest devam eder)', s)
      bildir('giris', s, '✅ Oyuna girdi (AFK bölgesine gitmeyecek, altın cevheri atacak)')
      setTimeout(async () => { try { await gunlukOdulKontrol(s, bot, 'giris') } catch (e) {} girisSirasiBitir(s, 'altin hesabi hazir, siradaki hesaba geciliyor') }, A.GUNLUK_BASLAMA_BEKLEME)
      return
    }
    asamaYaz(s, beaconHesabi(s) ? 'Beacon\'a gidiliyor' : 'Warp AFK\'ya gidiliyor')
    afkaGit(s, bot, (ok) => { if (ok === false) { asamaYaz(s, 'AFK noktasina gidilemedi'); girisSirasiBitir(s, 'AFK noktasina gidilemedi, siradaki hesaba geciliyor'); return } asamaYaz(s, 'AFK bolgesinde'); bildir('giris', s, '✅ AFK bölgesine ulaştı'); s.afkta = true; s.afktaZamani = Date.now(); setTimeout(async () => { try { await gunlukOdulKontrol(s, bot, 'giris') } catch (e) {} girisSirasiBitir(s, 'baslangic isleri tamamlandi') }, A.GUNLUK_BASLAMA_BEKLEME) })
  }, A.MENU_SONRASI_BEKLEME)
}

function sureYazi(ms) {
  if (ms >= 3600000) return (ms / 3600000) + ' saat'
  if (ms >= 60000) return (ms / 60000) + ' dk'
  return (ms / 1000) + ' sn'
}

// Atilma / hata / kopma sebebine gore yeniden deneme suresi (oncelik: bakim > ag protokolu > baglanti kesildi)
function kopmaSebebi(metin) {
  if (/bak[ıiİI]m|maintenance/i.test(metin)) return { asama: 'Sunucu bakimda', ad: 'Sunucu bakimda', bekleme: A.BAKIM_BEKLEME }
  if (/a[ğg]\s*protokol|network protocol|protocol error|PartialReadError|Unexpected buffer|Chunk size/i.test(metin)) return { asama: 'Ag protokolu hatasi', ad: 'Ag protokolu hatasi', bekleme: A.PROTOKOL_BEKLEME }
  if (/ba[ğg]lant[ıi]\s*kesil|connection lost|disconnected|socketClosed|ECONNRESET|ETIMEDOUT|timed? ?out|EPIPE/i.test(metin)) return { asama: 'Baglanti kesildi', ad: 'Baglanti kesildi', bekleme: A.KESILDI_BEKLEME }
  return null
}

// ---------- Giris sirasi: hesaplar ayni anda degil, sirayla girer ----------
// Bir hesap baglanip /login, /opskyblock, /warp afk ve gunluk odul islerini bitirince siradaki hesap baglanir.
const girisKuyrugu = []   // { s, baslat }
let girisAktif = null
let girisZamanAsimi = null

function girisSirasiIste(s, baslat) {
  if (girisAktif === s || girisKuyrugu.some((k) => k.s === s)) return
  girisKuyrugu.push({ s, baslat })
  if (girisAktif) { asamaYaz(s, 'Sirada'); log('Giris sirasi: ' + girisKuyrugu.length + '. sirada bekliyor', s) }
  girisSirasiIlerle()
}

function girisSirasiIlerle() {
  if (girisAktif) return
  const sonraki = girisKuyrugu.shift()
  if (!sonraki) return
  if (!sonraki.s.calisiyor || sonraki.s.cikarildi) return girisSirasiIlerle()
  girisAktif = sonraki.s
  girisZamanAsimi = setTimeout(() => girisSirasiBitir(sonraki.s, 'zaman asimi (' + Math.round(A.SIRA_ZAMAN_ASIMI / 1000) + ' sn), siradaki hesaba geciliyor'), A.SIRA_ZAMAN_ASIMI)
  try { sonraki.baslat() } catch (e) { log('Siradaki hesap baslatilamadi: ' + e.message, sonraki.s); girisSirasiBitir(sonraki.s, 'hata, siradaki hesaba geciliyor') }
}

function girisSirasiBitir(s, neden) {
  if (girisAktif !== s) return
  clearTimeout(girisZamanAsimi)
  girisAktif = null
  log('Giris sirasi: ' + neden + (girisKuyrugu.length ? ' (' + girisKuyrugu.length + ' hesap sirada)' : ''), s)
  setTimeout(girisSirasiIlerle, A.HESAP_ARALIK)   // hesaplar arasi kisa bekleme (sunucu baglanti sinirina takilmamak icin)
}

function girisSirasindanCikar(s) {
  const i = girisKuyrugu.findIndex((k) => k.s === s)
  if (i !== -1) girisKuyrugu.splice(i, 1)
  girisSirasiBitir(s, 'hesap durduruldu')
}
// ---------- /Giris sirasi ----------

function baglan(s) {
  if (!s.calisiyor || s.cikarildi) return
  girisSirasiIste(s, () => baglanGercek(s))
}

function baglanGercek(s) {
  if (!s.calisiyor || s.cikarildi) return
  s.sonAkisZamani = 0   // yeni baglanti: OpSkyblock akisi her zaman calismali
  s.sebepler = []
  s.afkta = false
  s.altinHazir = false
  asamaYaz(s, 'Baglaniyor')
  log('Baglaniyor: ' + A.HOST, s)
  let bot
  try {
    bot = mineflayer.createBot({
      host: A.HOST,
      port: A.PORT,
      username: s.profil.kullanici,
      auth: 'offline',
      viewDistance: A.GORUS_MESAFESI,   // hesap basina bellek kullanimini dusurur
      ...(A.VERSION ? { version: A.VERSION } : {}),
      // SRV aramasini atla, dogrudan TCP baglantisi kur (Android'de DNS/SRV takilmasina karsi)
      connect: (client) => {
        log('TCP baglantisi deneniyor...', s)
        const sock = net.connect({ host: A.HOST, port: A.PORT })
        sock.setTimeout(15000, () => { log('TCP zaman asimi (15 sn): sunucuya ulasilamiyor', s); sock.destroy() })
        sock.on('connect', () => { sock.setTimeout(0); log('TCP baglantisi kuruldu', s) })
        sock.on('error', (e) => log('Soket hatasi: ' + e.message, s))
        client.setSocket(sock)
        client.emit('connect')
      }
    })
  } catch (e) {
    log('createBot hatasi: ' + e.message, s)
    s.timer = setTimeout(() => baglan(s), 10000)
    return
  }
  s.bot = bot
  bot.once('login', () => log('Sunucuya el sikisma tamam (login)', s))

  // ---- Tani gunlukleri: login sonrasi spawn gelmezse nedenini gostermek icin ----
  const paketler = []
  let spawnGeldi = false
  try {
    bot._client.on('packet', (data, meta) => {
      if (spawnGeldi || !meta || paketler.length >= 60) return
      if (paketler[paketler.length - 1] !== meta.name) paketler.push(meta.name)
    })
  } catch (e) {}
  bot.once('spawn', () => { spawnGeldi = true; log('spawn olayi geldi', s) })
  bot.once('login', () => {
    setTimeout(() => {
      if (!spawnGeldi && !s.girisYapildi && s.bot === bot) log('Login sonrasi 20 sn: spawn gelmedi. Gelen paketler: ' + (paketler.join(', ') || '(yok)'), s)
    }, 20000)
  })
  bot.on('messagestr', (m, p) => { if (p !== 'game_info' && (!s.girisYapildi || Date.now() < s.sohbetDinleBitis)) { const t = skorTemizle(m); if (t) log('Sunucu: ' + t, s) } })
  // Texture / resource pack istegini otomatik kabul et (3 = kabul edildi, 4 = indirildi, 0 = basariyla yuklendi)
  const rpKabul = (paket) => {
    const uuid = paket && paket.uuid
    log('Texture pack istegi geldi, kabul ediliyor', s)
    const yaz = (sonuc) => {
      try { bot._client.write('resource_pack_receive', uuid ? { uuid, result: sonuc } : { result: sonuc }) } catch (e) { log('Texture pack yaniti gonderilemedi: ' + e.message, s) }
    }
    setTimeout(() => yaz(3), 300)
    setTimeout(() => yaz(4), 800)
    setTimeout(() => { yaz(0); log('Texture pack kabul edildi', s) }, 1300)
  }
  try {
    bot._client.on('add_resource_pack', rpKabul)    // 1.20.3 ve uzeri
    bot._client.on('resource_pack_send', rpKabul)   // eski surumler
  } catch (e) {}
  bot.on('end', (r) => log('Baglanti kapandi: ' + (r || '(sebep yok)'), s))
  s.girisYapildi = false
  skorTakipBaslat(s, bot)
  bot.on('messagestr', (m, p) => { if (p !== 'game_info') tradeMesajKontrol(s, bot, m) })

  // 'spawn' olayi bazi surum donusumlerinde hic gelmeyebiliyor; spawn, position paketi veya login+8 sn: hangisi once gelirse
  const girisBaslat = (kaynak) => {
    if (!s.calisiyor || s.bot !== bot || s.girisYapildi) return
    s.girisYapildi = true
    log('Sunucuya girildi (' + kaynak + ')', s)
    bildir('giris', s, '✅ Sunucuya girdi')
    asamaYaz(s, 'Giris yapiliyor')
    setTimeout(() => {
      if (!s.calisiyor || s.bot !== bot) return
      try { bot.chat('/login ' + s.profil.sifre); log('/login gonderildi', s) } catch (e) {}
    }, A.LOGIN_BEKLEME)
    const normal = A.LOGIN_BEKLEME + A.OYUN_BEKLEME
    const restart = hedefeKalanMs()
    if (restart > normal) log('Restart saati bekleniyor: ' + A.RESTART_SAAT + ' (' + Math.round(restart / 1000) + ' sn)', s)
    setTimeout(() => prisonAkisi(s, bot, 'giris'), Math.max(normal, restart))
  }
  bot.on('spawn', () => girisBaslat('spawn'))
  try { bot._client.once('position', () => setTimeout(() => girisBaslat('position paketi'), 3000)) } catch (e) {}
  bot.once('login', () => setTimeout(() => girisBaslat('login + 8 sn'), 8000))

  bot.on('kicked', (r) => {
    const sebep = skorTemizle(bilesenMetni(r))
    log('Atildi: ' + sebep, s)
    s.sebepler.push(sebep)
  })
  bot.on('error', (e) => { log('Hata: ' + e.message, s); s.sebepler.push(String(e && e.message)) })
  bot.on('end', (r) => {
    if (!s.calisiyor || s.bot !== bot) return
    if (girisAktif === s) girisSirasiBitir(s, 'baglanti koptu, siradaki hesaba geciliyor')
    const k = kopmaSebebi(s.sebepler.join(' | ') + ' | ' + String(r || ''))
    const sebepMetni = (s.sebepler.join(' | ') || String(r || '')).slice(0, 200)
    if (k) {
      asamaYaz(s, k.asama)
      log(k.ad + ', ' + sureYazi(k.bekleme) + ' sonra tekrar denenecek', s)
      bildir(k.asama === 'Sunucu bakimda' ? 'bakim' : 'kopma', s, (k.asama === 'Sunucu bakimda' ? '⚙ Sunucu bakımda' : '⚠️ ' + k.ad) + ', ' + sureYazi(k.bekleme) + ' sonra tekrar denenecek' + (sebepMetni ? '\n' + sebepMetni : ''))
      s.timer = setTimeout(() => baglan(s), k.bekleme)
      return
    }
    asamaYaz(s, 'Yeniden baglaniyor')
    log('Baglanti koptu, 10 sn sonra tekrar denenecek', s)
    bildir('kopma', s, '⚠️ Bağlantı koptu, 10 sn sonra tekrar denenecek' + (sebepMetni ? '\n' + sebepMetni : ''))
    s.timer = setTimeout(() => baglan(s), 10000)
  })
}

// gecikme > 0 ise hesap "Sirada" olarak gorunur ve o kadar sonra baglanir (sunucu baglanti sinirina takilmamak icin)
function hesapBaslat(h, alici, kaynak, gecikme) {
  const anahtar = h.kullanici.toLowerCase()
  if (oturumlar.has(anahtar)) return
  const s = {
    profil: { kullanici: h.kullanici, sifre: h.sifre, alici },
    bot: null, calisiyor: true, asama: gecikme ? 'Sirada' : 'Baslatiliyor', timer: null,
    tradeMesgul: false, tradeSirada: false, sonTradeZamani: 0, sonAkisZamani: 0, sonZamanlayiciTarih: '',
    sebepler: [], girisYapildi: false, sohbetDinleBitis: 0, skor: bosSkor()
  }
  oturumlar.set(anahtar, s)
  log('Baslatildi (' + kaynak + ')' + (gecikme ? ', ' + Math.round(gecikme / 1000) + ' sn sonra baglanacak' : ''), s)
  bildir('durum', s, 'ℹ️ Başlatıldı (' + kaynak + ')')
  try {
    const hf = odulOku()
    log('Yerel tarih/saat: ' + yerelSaatYazi() + ' | son gunluk odul: ' + (hf.odul[anahtar] ? tarihGoster(hf.odul[anahtar]) : '(kayit yok)') + (hf.baslangic[anahtar] ? ' | onceki baslangic: ' + hf.baslangic[anahtar] : ''), s)
    hf.baslangic[anahtar] = yerelSaatYazi()
    odulKaydet()
  } catch (e) {}
  s.timer = setTimeout(() => baglan(s), gecikme)
}

function hepsiniBaslat(profil, kaynak) {
  let sira = 0
  for (const h of profil.hesaplar) {
    if (oturumlar.has(h.kullanici.toLowerCase())) continue
    hesapBaslat(h, profil.alici, kaynak, 0)
    sira++
  }
  if (profil.hesaplar.length > 10) log('Uyari: ' + profil.hesaplar.length + ' hesap telefonu yorabilir')
  durumGonder()
}

function hesapDurdur(s, sebep) {
  s.calisiyor = false
  clearTimeout(s.timer)
  girisSirasindanCikar(s)
  s.asama = 'Durdu'
  try { if (s.bot) s.bot.quit() } catch (e) {}
  oturumlar.delete(s.profil.kullanici.toLowerCase())
  log('Durduruldu' + (sebep ? ' (' + sebep + ')' : ''), s)
  bildir('durum', s, 'ℹ️ Durduruldu' + (sebep ? ' (' + sebep + ')' : ''))
}

function hepsiniDurdur(sebep) {
  for (const s of Array.from(oturumlar.values())) hesapDurdur(s, sebep)
  durumGonder()
}

// Her gun RESTART_SAAT'te bagli her hesap icin OpSkyblock akisini bastan calistir
setInterval(() => {
  const t = simdi()
  if (!A.RESTART_SAAT || t.saat !== A.RESTART_SAAT) return
  for (const s of oturumlar.values()) {
    if (!s.calisiyor || s.cikarildi || s.sonZamanlayiciTarih === t.tarih) continue
    s.sonZamanlayiciTarih = t.tarih
    if (s.bot && canli(s, s.bot) && !s.tradeMesgul) {
      log('Zamanlayici ' + A.RESTART_SAAT + ': lobiden OpSkyblock\'a geciliyor', s)
      girisSirasiIste(s, () => prisonAkisi(s, s.bot, 'zamanlayici'))
    } else {
      log('Zamanlayici ' + A.RESTART_SAAT + ': bagli degil, baglaninca akis kendiliginden calisir', s)
    }
  }
}, 10000)

// ---------- Esya trade: trade ekranina sadece anahtar (trail_key / trial_key) koy ----------
let esyaTradeKuyruk = Promise.resolve()

function esyaTradeUygun(it) {
  if (!it) return false
  const ad = String(it.name || '').replace(/^minecraft:/, '').toLowerCase()
  if (A.TRADE_ESYA_ADLARI.indexOf(ad) !== -1) return true
  let metin = ''
  try { metin = String(it.customName || '') + ' ' + String(it.displayName || '') + ' ' + JSON.stringify(it.nbt || '') } catch (e) {}
  return A.TRADE_ESYA_ISIM.test(metin)
}

function pencereTikla(bot, slot, buton, mod) {
  return Promise.race([
    bot.clickWindow(slot, buton, mod).then(() => 'tamam'),
    new Promise((r) => setTimeout(() => r('onay gelmedi'), 4000))
  ])
}

function envanterOzeti(bot) {
  try { return bot.inventory.items().slice(0, 12).map((i) => i.name + ' x' + i.count).join(', ') || '(bos)' } catch (e) { return '(okunamadi)' }
}

const mesafe3 = (a, b) => Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2)
const esyaAdedi = (bot) => { try { return bot.inventory.items().filter(esyaTradeUygun).reduce((t, i) => t + i.count, 0) } catch (e) { return 0 } }

async function esyaTradeCalistir(s, bot) {
  const alici = s.profil.alici
  if (!alici) return
  if (!canli(s, bot)) { log('Trade iptal: bot sunucuda degil', s); return }
  if (s.tradeMesgul) { log('Trade atlandi: baska bir takas suruyor', s); return }
  const sahip = bot.inventory.items().filter(esyaTradeUygun)
  if (!sahip.length) {
    log('Trade atlandi: envanterde trade esyasi (' + A.TRADE_ESYA_ADLARI.join(' / ') + ') yok. Envanter: ' + envanterOzeti(bot), s)
    bildir('trade', s, '❗ Trade atlandı: envanterde anahtar yok')
    return
  }
  const adet = sahip.reduce((t, i) => t + i.count, 0)
  s.tradeMesgul = true
  let yerDegisti = false
  let kapanisDinleyici = null
  let donusBekleme = 1000   // hata/iptal durumlarinda warp'tan once kisa bekleme; basarili akista onay sonrasi bekleme zaten yapildi
  try {
    // 1) /tpa: aliciya isinlan
    const bas0 = bot.entity && bot.entity.position ? { x: bot.entity.position.x, y: bot.entity.position.y, z: bot.entity.position.z } : null
    bot.chat(A.TPA_KOMUTU + ' ' + alici)
    log(A.TPA_KOMUTU + ' ' + alici + ' gonderildi. Alicinin kabul etmesi bekleniyor, en fazla ' + (A.TPA_BEKLEME / 1000) + ' sn', s)
    asamaYaz(s, 'Trade icin isinlaniyor')
    const tpaBitis = Date.now() + A.TPA_BEKLEME
    while (Date.now() < tpaBitis && canli(s, bot)) {
      await bekle(1000)
      if (bas0 && bot.entity && bot.entity.position && mesafe3(bot.entity.position, bas0) >= A.ISINLANMA_ESIK) { yerDegisti = true; break }
    }
    if (!canli(s, bot)) return
    if (!yerDegisti) {
      log('/tpa ' + (A.TPA_BEKLEME / 1000) + ' sn icinde kabul edilmedi, trade iptal edildi', s)
      bildir('trade', s, '❗ Trade iptal: /tpa ' + (A.TPA_BEKLEME / 1000) + ' sn içinde kabul edilmedi')
      return
    }
    log('Isinlanma tamam, ' + (A.ESYA_TPA_SONRASI_BEKLEME / 1000) + ' sn sonra trade istegine geciliyor', s)
    await bekle(A.ESYA_TPA_SONRASI_BEKLEME)
    if (!canli(s, bot)) return

    // 2) /trade: trade ekranini ac
    asamaYaz(s, 'Trade yapiliyor')
    const pencere = new Promise((coz) => {
      const f = (w) => { clearTimeout(t); coz(w) }
      const t = setTimeout(() => { bot.removeListener('windowOpen', f); coz(null) }, A.TRADE_PENCERE_BEKLEME)
      bot.once('windowOpen', f)
    })
    bot.chat(A.TRADE_KOMUTU + ' ' + alici)
    log(A.TRADE_KOMUTU + ' ' + alici + ' gonderildi (' + adet + ' adet trade esyasi var). Alicinin istegi kabul etmesi bekleniyor, en fazla ' + (A.TRADE_PENCERE_BEKLEME / 1000) + ' sn', s)
    const win = await pencere
    if (!win) {
      log('Trade ekrani acilmadi: alici istegi kabul etmemis olabilir', s)
      bildir('trade', s, '❗ Trade ekranı açılmadı (alıcı kabul etmedi mi?)')
      return
    }
    yerDegisti = true
    const acilis = Date.now()
    // Ekran ne zaman kapanirsa kapansin kacirmamak icin dinleyiciyi hemen kur
    let ekranKapandi = false
    const kapanisSozu = new Promise((coz) => {
      kapanisDinleyici = () => { ekranKapandi = true; coz(true) }
      bot.once('windowClose', kapanisDinleyici)
    })
    await bekle(800)   // pencere icerigi dolsun
    const w = bot.currentWindow || win
    const bas = typeof w.inventoryStart === 'number' ? w.inventoryStart : 0
    // trade ekraninin icerigini gunluge yaz (cam / cam panel gibi dolgu esyalari haric)
    try {
      let baslik = ''
      try { baslik = skorTemizle(bilesenMetni(w.title)) } catch (e) { baslik = String(w.title) }
      const liste = []
      for (let i = 0; i < bas; i++) {
        const x = w.slots[i]
        if (x && !A.TRADE_DOKUM_GIZLE.test(String(x.name))) liste.push(i + ':' + (x.displayName || x.name))
      }
      log('Trade ekrani acildi: "' + baslik + '" (' + bas + ' slot). Dolu slotlar: ' + (liste.join(', ') || '(bos)'), s)
    } catch (e) {}

    // 3) sadece trade esyalarini ekrana koy
    const kaynaklar = []
    for (let i = bas; i < w.slots.length; i++) if (esyaTradeUygun(w.slots[i])) kaynaklar.push(i)
    if (!kaynaklar.length) { log('Trade ekraninda envanter bolumunde trade esyasi bulunamadi', s); bildir('trade', s, '❗ Trade ekranında anahtar bulunamadı'); return }
    const once = kaynaklar.reduce((t, i) => t + w.slots[i].count, 0)
    const hedefler = A.TRADE_HEDEF_SLOTLAR.slice()
    const bosHedef = () => {
      const cur = bot.currentWindow || w
      for (let i = 0; i < bas; i++) if (!cur.slots[i] && A.TRADE_SOL_SUTUNLAR.indexOf(i % 9) !== -1) return i
      return -1
    }
    let mod = A.TRADE_HEDEF_SLOTLAR.length ? 'sabit' : 'shift'
    for (const kaynak of kaynaklar) {
      if (!canli(s, bot) || ekranKapandi) break
      try {
        if (mod === 'shift') {
          await pencereTikla(bot, kaynak, 0, 1)   // shift+tikla: trade ekranina tasi
          await bekle(700)
          const hala = (bot.currentWindow || w).slots[kaynak]
          if (hala && esyaTradeUygun(hala)) { mod = 'otomatik'; log('Shift+tikla ise yaramadi, bos slotlara tek tek konacak (sutunlar: ' + A.TRADE_SOL_SUTUNLAR.join(',') + ')', s) }
        }
        if (mod !== 'shift' && (bot.currentWindow || w).slots[kaynak]) {
          const hedef = mod === 'sabit' ? hedefler.shift() : bosHedef()
          if (hedef === undefined || hedef < 0) { log('Trade ekraninda yerlestirilecek bos slot kalmadi', s); break }
          await pencereTikla(bot, kaynak, 0, 0)   // esyayi eline al
          await pencereTikla(bot, hedef, 0, 0)    // hedef slota birak
        }
      } catch (e) { log('Trade tiklama hatasi: ' + e.message, s) }
      await bekle(A.TRADE_TIKLA_ARALIK)
    }
    await bekle(1000)
    if (ekranKapandi) { log('Trade ekrani esyalar konurken kapandi (alici iptal etmis olabilir)', s); bildir('trade', s, '❗ Trade ekranı onaydan önce kapandı'); return }
    const w2 = bot.currentWindow || w
    let sonra = 0
    for (let i = bas; i < w2.slots.length; i++) if (esyaTradeUygun(w2.slots[i])) sonra += w2.slots[i].count
    const konan = Math.max(0, once - sonra)
    if (konan <= 0) {
      log('Esyalar yerlestirilemedi. Yukaridaki "Dolu slotlar" satirina bakip TRADE_HEDEF_SLOTLAR ayarla', s)
      bildir('trade', s, '❗ Anahtarlar trade ekranına yerleştirilemedi')
      try { bot.closeWindow(w2) } catch (e) {}
      return
    }
    log(konan + ' adet trade esyasi trade ekranina konuldu', s)

    // 4) onay dugmesine bas
    await bekle(A.TRADE_ONAY_BEKLEME)
    const ilkBekle = A.ESYA_ONAY_ILK_BEKLEME - (Date.now() - acilis)
    if (ilkBekle > 0 && !ekranKapandi) { log('Trade onay suresi icin ' + Math.ceil(ilkBekle / 1000) + ' sn daha bekleniyor', s); await bekle(ilkBekle) }
    const onayOnce = ekranKapandi ? null : (bot.currentWindow || w2).slots[A.TRADE_ONAY_SLOT]
    if (ekranKapandi) {
      log('Trade ekrani onaydan once kapandi', s)
    } else if (!onayOnce) {
      log('Onay slotu (' + A.TRADE_ONAY_SLOT + ') bos, onay tiklanmadi. TRADE_ONAY_SLOT degerini kontrol et', s)
    } else {
      log('Onay slotu ' + A.TRADE_ONAY_SLOT + ': ' + (onayOnce.displayName || onayOnce.name) + ' (' + onayOnce.name + ') tiklaniyor', s)
      await pencereTikla(bot, A.TRADE_ONAY_SLOT, 0, 0)
      await bekle(1200)
      const onaySonra = ekranKapandi ? null : (bot.currentWindow || w2).slots[A.TRADE_ONAY_SLOT]
      log('Onay tiklandi, slot simdi: ' + (onaySonra ? (onaySonra.displayName || onaySonra.name) + ' (' + onaySonra.name + ')' : '(bos / ekran kapandi)'), s)
    }
    bildir('trade', s, '⇄ ' + konan + ' adet anahtar trade ekranına konuldu ve onaylandı → ' + alici)

    // 5) onaydan sonra 6 sn bekle; ekran hala aciksa kapat (trade iptal olur), sonra sonucu degerlendir
    if (!ekranKapandi) await bekle(A.ESYA_ONAY_SONRASI_BEKLEME)
    if (!ekranKapandi) {
      log('Trade ' + (A.ESYA_ONAY_SONRASI_BEKLEME / 1000) + ' sn icinde tamamlanmadi (alici onaylamamis), ekran kapatiliyor', s)
      try { bot.closeWindow(bot.currentWindow || w2) } catch (e) {}
    }
    await bekle(1000)   // envanter guncellensin
    const kalan = esyaAdedi(bot)
    if (kalan < adet) {
      log('Trade tamamlandi: ' + (adet - kalan) + ' adet anahtar gitti', s)
      bildir('trade', s, '✅ Trade tamamlandı: ' + (adet - kalan) + ' adet anahtar gitti → ' + alici)
    } else {
      log('Trade tamamlanmadi: anahtarlar envanterde kaldi (trade iptal olmus)', s)
      bildir('trade', s, '❗ Trade tamamlanmadı, iptal oldu (anahtarlar geri geldi)')
    }
    donusBekleme = 0   // zaten bekledik
  } catch (e) {
    log('Trade hatasi: ' + e.message, s)
    bildir('trade', s, '❗ Trade hatası: ' + e.message)
  } finally {
    if (kapanisDinleyici) { try { bot.removeListener('windowClose', kapanisDinleyici) } catch (e) {} }
    // 6) isinlandiysak ya da trade ekrani actiysak AFK bolgesine don
    try {
      if (yerDegisti && canli(s, bot)) {
        log('Trade bitti, ' + (beaconHesabi(s) ? A.BEACON_KOMUTU : A.WARP_KOMUTU) + ' ile AFK bolgesine donuluyor', s)
        if (donusBekleme > 0) await bekle(donusBekleme)
        if (canli(s, bot)) {
          asamaYaz(s, 'AFK bolgesine donuluyor')
          await new Promise((coz) => {
            afkaGit(s, bot, () => { asamaYaz(s, 'AFK bolgesinde'); coz() })
            setTimeout(coz, 60000)
          })
        }
      } else if (canli(s, bot)) asamaYaz(s, s.altinHazir ? 'Altin atiyor' : 'AFK bolgesinde')
    } catch (e) { log('AFK donus hatasi: ' + e.message, s) }
    s.tradeMesgul = false
  }
}

channel.addListener('esyaTrade', () => {
  if (oturumlar.size === 0) { log('Trade icin once hesaplari baslat'); return }
  if (!Array.from(oturumlar.values()).some((x) => x.profil.alici)) { log('Trade hesabi girilmemis, trade yapilmaz'); return }
  for (const s of oturumlar.values()) {
    if (!s.profil.alici || !s.bot || s.altinHazir) continue
    if (s.esyaTradeSirada) { log('Trade zaten sirada', s); continue }
    s.esyaTradeSirada = true
    esyaTradeKuyruk = esyaTradeKuyruk
      .then(() => esyaTradeCalistir(s, s.bot))
      .catch((e) => log('Trade hatasi: ' + (e && e.message), s))
      .then(() => { s.esyaTradeSirada = false })
  }
})

// ---------- Gunluk odul: yerel tarihi takip et, hafizada tut, her gun /gunluk odul menusunden al ----------
let yerelSapmaDk = null   // arayuzden gelen JS getTimezoneOffset() (UTC+3 icin -180). Android'de Node saat dilimini bilmeyebilir

const iki = (n) => String(n).padStart(2, '0')
function yerelParcalar() {
  const sapma = yerelSapmaDk === null ? new Date().getTimezoneOffset() : yerelSapmaDk
  const d = new Date(Date.now() - sapma * 60000)
  return { y: d.getUTCFullYear(), a: d.getUTCMonth() + 1, g: d.getUTCDate(), sa: d.getUTCHours(), dk: d.getUTCMinutes() }
}
function yerelTarih() { const p = yerelParcalar(); return p.y + '-' + iki(p.a) + '-' + iki(p.g) }
function tarihGoster(iso) { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || ''); return m ? m[3] + '.' + m[2] + '.' + m[1] : String(iso) }
function yerelSaatYazi() { const p = yerelParcalar(); return iki(p.g) + '.' + iki(p.a) + '.' + p.y + ' ' + iki(p.sa) + ':' + iki(p.dk) }

channel.addListener('saat', (veri) => {
  const sapma = Number(veri && veri.sapma)
  if (!Number.isFinite(sapma) || Math.abs(sapma) > 840) return
  const ilk = yerelSapmaDk === null
  yerelSapmaDk = sapma
  if (ilk) log('Yerel saat alindi: ' + yerelSaatYazi())
})

// Hafiza: hesap basina son alinan odul tarihi ve son baslangic zamani (sifreli dosyada, uygulama kapansa da kalir)
let odulOnbellek = null
function odulOku() {
  if (odulOnbellek) return odulOnbellek
  const t = sifreliOku('o.bin') || {}
  odulOnbellek = { odul: t.odul || {}, baslangic: t.baslangic || {} }
  return odulOnbellek
}
function odulKaydet() { try { sifreliYaz('o.bin', odulOnbellek) } catch (e) {} }

function komutlaPencereAc(bot, komut, ms) {
  return new Promise((coz) => {
    const f = (w) => { clearTimeout(t); coz(w) }
    const t = setTimeout(() => { bot.removeListener('windowOpen', f); coz(null) }, ms)
    bot.once('windowOpen', f)
    try { bot.chat(komut) } catch (e) { clearTimeout(t); bot.removeListener('windowOpen', f); coz(null) }
  })
}

async function gunlukOdulKontrol(s, bot, kaynak, zorla) {
  if (!A.GUNLUK_ACIK || !canli(s, bot)) return
  if (s.tradeMesgul || s.odulMesgul) { if (zorla) log('Ödül alınamadı: hesap başka bir işlemle meşgul', s); return }
  const bugun = yerelTarih()
  const kayit = odulOku()
  const ad = s.profil.kullanici.toLowerCase()
  if (kayit.odul[ad] === bugun && !zorla) return   // bugun zaten alindi (buton ile basilirsa yine bakilir)
  const d = (s.odulDeneme && s.odulDeneme.tarih === bugun) ? s.odulDeneme : (s.odulDeneme = { tarih: bugun, sayi: 0, son: 0 })
  if (!zorla && (d.sayi >= A.GUNLUK_MAKS_DENEME || Date.now() - d.son < A.GUNLUK_TEKRAR_ARALIK)) return
  d.sayi++
  d.son = Date.now()
  s.odulMesgul = true
  s.tradeMesgul = true   // trade / dinar ve menu isleyicileri araya girmesin
  const cevap = []
  const dinle = (m, p) => { if (p !== 'game_info') cevap.push(skorTemizle(m)) }
  // Gunlukte sadece sonuc yazilir: "Ödül alındı: ..." ya da "Ödül alınamadı: sebep" (pencere icerigi yazdirilmaz)
  const alindi = (oduller, kaydet) => {
    if (kaydet) { kayit.odul[ad] = bugun; odulKaydet() }
    log('Ödül alındı: ' + oduller, s)
    bildir('odul', s, '★ Ödül alındı: ' + oduller)
  }
  const alinamadi = (sebep, kaydet, hata) => {
    if (kaydet) { kayit.odul[ad] = bugun; odulKaydet() }
    log('Ödül alınamadı: ' + sebep, s)
    bildir(hata ? 'sorun' : 'odul', s, (hata ? '❗ ' : '★ ') + 'Ödül alınamadı: ' + sebep)
  }
  try {
    asamaYaz(s, 'Gunluk odul kontrol ediliyor')
    let win = null
    for (const komut of A.GUNLUK_KOMUTLAR) {
      win = await komutlaPencereAc(bot, komut, A.GUNLUK_PENCERE_BEKLEME)
      if (win) break
      if (!canli(s, bot)) return
    }
    if (!win) return alinamadi('günlük ödül menüsü açılmadı (' + A.GUNLUK_KOMUTLAR.join(', ') + ')', false, true)
    await bekle(A.GUNLUK_TIKLA_BEKLEME)
    const w = bot.currentWindow || win
    const ust = typeof w.inventoryStart === 'number' ? w.inventoryStart : w.slots.length
    const sandikMi = (it) => !!it && String(it.name).replace(/^minecraft:/, '') === A.GUNLUK_ODUL_ESYA

    const slotlar = A.GUNLUK_SLOTLAR || Array.from({ length: ust }, (_, i) => i)
    let hedef = -1
    for (const i of slotlar) if (i < ust && sandikMi(w.slots[i])) { hedef = i; break }
    if (hedef < 0) {
      let yesilVar = false
      for (const i of slotlar) if (i < ust && w.slots[i] && A.GUNLUK_ALINDI_ESLESME.test(String(w.slots[i].name))) { yesilVar = true; break }
      if (!yesilVar) return alinamadi('menü tanınmadı (ne ' + A.GUNLUK_ODUL_ESYA + ' ne de alınmış ödül işareti var)', false, true)
      return alinamadi('bugün zaten alınmış', true, false)
    }
    const gun = w.slots[hedef].count
    bot.on('messagestr', dinle)
    await Promise.race([
      bot.clickWindow(hedef, 0, 0).then(() => 'tamam'),
      new Promise((r) => setTimeout(() => r('onay gelmedi'), 4000))
    ])
    await bekle(A.GUNLUK_SONUC_BEKLEME)
    bot.removeListener('messagestr', dinle)
    const cur = bot.currentWindow
    const yeni = cur && cur.slots ? cur.slots[hedef] : null
    const iliskili = cevap.filter((t) => /[öo]d[üu]l|reward|ald[ıi]n|kazan|\d+\s*x|x\s*\d+/i.test(t))
    const mesaj = (iliskili.length ? iliskili : cevap).join(' | ').slice(0, 250)
    if (yeni && !sandikMi(yeni)) alindi(mesaj || (gun + '. gün ödülü'), true)
    else if (yeni && A.GUNLUK_ZATEN_ESLESME.test(mesaj)) alinamadi('bugün zaten alınmış (' + mesaj + ')', true, false)
    else if (!cur) alindi(mesaj || (gun + '. gün ödülü'), true)   // menu kapandi: alindi sayilir
    else alinamadi(mesaj || 'sandığa tıklandı ama ödül verilmedi', false, true)
  } catch (e) {
    log('Ödül alınamadı: ' + e.message, s)
  } finally {
    try { bot.removeListener('messagestr', dinle) } catch (e) {}
    try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow) } catch (e) {}
    s.odulMesgul = false
    s.tradeMesgul = false
    if (canli(s, bot)) asamaYaz(s, s.altinHazir ? 'Altin atiyor' : 'AFK bolgesinde')
  }
}

// Gece yarisi tarih degisince (ya da basarisiz deneme tekrari) AFK'daki hesaplar icin kontrol et
function gunlukIzleyici() {
  if (!A.GUNLUK_ACIK) return
  for (const s of oturumlar.values()) {
    if ((!s.afkta && !s.altinHazir) || !s.bot || s.odulMesgul || s.tradeMesgul) continue
    if (!canli(s, s.bot)) continue
    gunlukOdulKontrol(s, s.bot, 'izleyici')
  }
}
setInterval(gunlukIzleyici, 30000)

// ---------- Ada sandigi: envanterdeki spawner / anahtar / etkinlik kemigini /is chest ile 1. sandiga, dolunca siradaki sandiga (21 sandik) koy ----------
let depoKuyruk = Promise.resolve()   // hesaplar sirayla sandik kullansin (ayni anda ayni sandiga erismesin)

function depoUygun(it) {
  if (!it) return false
  if (esyaTradeUygun(it)) return true   // trail_key / trial_key
  const ad = String(it.name || '').replace(/^minecraft:/, '').toLowerCase()
  if (A.DEPO_ESYA_ADLARI.indexOf(ad) !== -1) return true
  for (const o of A.DEPO_OZEL_ESYALAR) {
    if (ad !== o.ad) continue
    let metin = ''
    try { metin = String(it.customName || '') + ' ' + String(it.displayName || '') + ' ' + JSON.stringify(it.nbt || '') } catch (e) {}
    if (o.isim.test(metin)) return true   // ornek: "Kurt Etkinlik Kemigi"
  }
  return false
}

const depoSayisi = (pencere, bas) => {
  let t = 0
  for (let i = bas; i < pencere.slots.length; i++) if (depoUygun(pencere.slots[i])) t += pencere.slots[i].count
  return t
}

async function adaSandigaKoy(s, bot, kaynak, zorla) {
  if (!A.DEPO_ACIK || !canli(s, bot)) return
  if (s.tradeMesgul || s.odulMesgul || s.depoMesgul) { if (zorla) log('Sandiga koyma simdi yapilamadi: hesap baska bir islemle mesgul', s); return }
  s.sonDepoZamani = Date.now()
  const baslangic = bot.inventory.items().filter(depoUygun)
  if (!baslangic.length) { if (zorla) log('Envanterde sandiga konacak esya (spawner / anahtar / etkinlik kemigi) yok', s); return }
  // dolu oldugu bilinen sandiklari (son DEPO_DOLU_HAFIZA icinde) atla; butonla basilirsa hepsi yeniden denenir
  if (zorla || !s.depoDolu) s.depoDolu = new Map()
  const adaylar = []
  A.DEPO_SANDIK_SLOTLARI.forEach((slot, idx) => {
    const t = s.depoDolu.get(slot)
    if (!t || Date.now() - t > A.DEPO_DOLU_HAFIZA) adaylar.push({ no: idx + 1, slot })
  })
  if (!adaylar.length) return   // hepsi dolu (hafizada); sure dolunca yeniden denenir
  const toplam = baslangic.reduce((t, i) => t + i.count, 0)
  s.depoMesgul = true
  s.tradeMesgul = true   // trade / gunluk odul araya girmesin
  const ozet = []
  try {
    log('Ada sandigina konacak esya: ' + toplam + ' adet (' + baslangic.slice(0, 6).map((i) => (i.displayName || i.name) + ' x' + i.count).join(', ') + ') [' + kaynak + ']', s)
    asamaYaz(s, 'Ada sandigina esya konuyor')
    let kalan = toplam
    let menuW = null   // acik "Ada Sandigi" menusu (sandik slotu bossa ayni menuden devam edilir)
    for (const aday of adaylar) {
      if (kalan <= 0) break
      if (!canli(s, bot)) return
      // 1) /is chest: Ada Sandigi menusu
      if (!menuW || bot.currentWindow !== menuW) {
        const menu = await komutlaPencereAc(bot, A.DEPO_KOMUTU, A.DEPO_PENCERE_BEKLEME)
        if (!menu) {
          log('Ada sandigi menusu acilmadi (' + A.DEPO_KOMUTU + ')', s)
          bildir('sorun', s, '❗ Ada sandığı menüsü açılmadı')
          return
        }
        await bekle(1200)
        menuW = bot.currentWindow || menu
      }
      if (!menuW.slots[aday.slot]) { s.depoDolu.set(aday.slot, Date.now()); continue }   // bu sandik yok / kullanilamiyor
      // 2) sandigi ac
      const acilan = new Promise((coz) => {
        const f = (w) => { clearTimeout(t); coz(w) }
        const t = setTimeout(() => { bot.removeListener('windowOpen', f); coz(null) }, A.DEPO_PENCERE_BEKLEME)
        bot.once('windowOpen', f)
      })
      await pencereTikla(bot, aday.slot, 0, 0)
      const yeni = await acilan
      await bekle(1200)
      const w = bot.currentWindow || yeni
      if (!w || w === menuW) { log(aday.no + '. sandik acilmadi (slot ' + aday.slot + ')', s); s.depoDolu.set(aday.slot, Date.now()); menuW = null; continue }
      menuW = null
      const bas = typeof w.inventoryStart === 'number' ? w.inventoryStart : 0
      const once = depoSayisi(w, bas)
      if (!once) { try { bot.closeWindow(w) } catch (e) {}; break }
      // 3) esyalari shift+tikla ile sandiga tasi
      for (let i = bas; i < w.slots.length; i++) {
        if (!canli(s, bot)) return
        const it = (bot.currentWindow || w).slots[i]
        if (!depoUygun(it)) continue
        const eski = it.count
        await pencereTikla(bot, i, 0, 1)
        await bekle(A.DEPO_TIKLA_ARALIK)
        const simdi = (bot.currentWindow || w).slots[i]
        if (simdi && depoUygun(simdi) && simdi.count >= eski) break   // sandik dolu
      }
      await bekle(800)
      const sonra = depoSayisi(bot.currentWindow || w, bas)
      const konan = Math.max(0, once - sonra)
      if (konan > 0) ozet.push(aday.no + '. sandik: ' + konan)
      kalan = sonra
      if (sonra > 0) s.depoDolu.set(aday.slot, Date.now())   // her seyi alamadiysa dolu say
      if (konan > 0) log(aday.no + '. sandiga ' + konan + ' adet konuldu' + (sonra > 0 ? ', envanterde ' + sonra + ' adet kaldi' : ''), s)
      try { bot.closeWindow(bot.currentWindow || w) } catch (e) {}
      await bekle(1000)
    }
    if (kalan > 0) {
      log('Tum ada sandiklari dolu: ' + kalan + ' adet esya envanterde kaldi', s)
      bildir('sorun', s, '❗ Tüm ada sandıkları dolu, ' + kalan + ' adet eşya envanterde kaldı' + (ozet.length ? ' (' + ozet.join(', ') + ')' : ''))
    } else {
      log('Ada sandigina koyma tamam (' + ozet.join(', ') + ')', s)
      bildir('depo', s, '▣ ' + toplam + ' adet eşya ada sandığına konuldu (' + ozet.join(', ') + ')')
    }
  } catch (e) {
    log('Ada sandigi hatasi: ' + e.message, s)
    bildir('sorun', s, '❗ Ada sandığı hatası: ' + e.message)
  } finally {
    try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow) } catch (e) {}
    s.depoMesgul = false
    s.tradeMesgul = false
    if (canli(s, bot)) asamaYaz(s, s.altinHazir ? 'Altin atiyor' : 'AFK bolgesinde')
  }
}

function depoSiraya(s, kaynak, zorla) {
  depoKuyruk = depoKuyruk
    .then(() => (s.bot ? adaSandigaKoy(s, s.bot, kaynak, zorla) : null))
    .catch((e) => log('Ada sandigi hatasi: ' + (e && e.message), s))
}

// Dakikada bir: AFK'daki hesaplarin envanterini kontrol et
function depoIzleyici() {
  if (!A.DEPO_ACIK) return
  const simdi = Date.now()
  for (const s of oturumlar.values()) {
    if ((!s.afkta && !s.altinHazir) || !s.bot || s.odulMesgul || s.tradeMesgul || s.depoMesgul || s.depoSirada) continue
    if (simdi - (s.afktaZamani || 0) < A.DEPO_ILK_BEKLEME) continue
    if (simdi - (s.sonDepoZamani || 0) < A.DEPO_ARALIK) continue
    if (!canli(s, s.bot)) continue
    s.depoSirada = true
    depoKuyruk = depoKuyruk
      .then(() => adaSandigaKoy(s, s.bot, 'saatlik'))
      .catch((e) => log('Ada sandigi hatasi: ' + (e && e.message), s))
      .then(() => { s.depoSirada = false })
  }
}
setInterval(depoIzleyici, 10000)

// Arayuzdeki dugmeler
channel.addListener('depo', () => {
  if (oturumlar.size === 0) { log('Sandiga koymak icin once hesaplari baslat'); return }
  for (const s of oturumlar.values()) if (s.bot) depoSiraya(s, 'buton', true)
})

let gunlukKuyruk = Promise.resolve()
channel.addListener('gunlukOdul', () => {
  if (oturumlar.size === 0) { log('Gunluk odul icin once hesaplari baslat'); return }
  for (const s of oturumlar.values()) {
    if (!s.bot) continue
    gunlukKuyruk = gunlukKuyruk
      .then(() => gunlukOdulKontrol(s, s.bot, 'buton', true))
      .catch((e) => log('Gunluk odul hatasi: ' + (e && e.message), s))
  }
})
// ---------- /Ada sandigi ----------

// ---------- Depolama raporu: uygulamanin veri klasorunde hangi klasor ne kadar yer tutuyor / hangisi buyuyor ----------
let oncekiDepolama = null
const mbYaz = (b) => (b / 1048576).toFixed(1) + ' MB'

async function boyutAgaci(p, derinlik, sayac) {
  let st
  try { st = await fs.promises.lstat(p) } catch (e) { return { yol: p, boyut: 0, cocuklar: [] } }
  if (st.isSymbolicLink()) return { yol: p, boyut: 0, cocuklar: [] }
  if (!st.isDirectory()) return { yol: p, boyut: st.size, cocuklar: [] }
  let liste = []
  try { liste = await fs.promises.readdir(p) } catch (e) {}
  let boyut = 0
  const cocuklar = []
  for (const a of liste) {
    if (++sayac.n > 400000) break
    const c = await boyutAgaci(path.join(p, a), derinlik - 1, sayac)
    boyut += c.boyut
    if (derinlik > 0) cocuklar.push(c)
  }
  return { yol: p, boyut, cocuklar }
}

function agaciDuzlestir(d, kok, harita) {
  harita.set(d.yol === kok ? '(kok)' : path.relative(kok, d.yol), d.boyut)
  for (const c of d.cocuklar) agaciDuzlestir(c, kok, harita)
}

let depolamaMesgul = false
async function depolamaRaporu() {
  if (depolamaMesgul) { log('Depolama raporu zaten hazirlaniyor'); return }
  depolamaMesgul = true
  try {
    const veri = getDataPath()
    const m = String(veri).match(/^(\/data\/(?:user\/\d+|data)\/[^/]+)/)
    const fi = String(veri).indexOf('/files')
    const kok = m ? m[1] : (fi > 0 ? String(veri).slice(0, fi) : path.dirname(veri))
    log('Depolama raporu hazirlaniyor (' + kok + ') ...')
    const sayac = { n: 0 }
    const agac = await boyutAgaci(kok, 3, sayac)
    const harita = new Map()
    agaciDuzlestir(agac, kok, harita)
    const mem = process.memoryUsage()
    log('Uygulama veri klasoru toplam: ' + mbYaz(agac.boyut) + ' | Bellek (RSS): ' + mbYaz(mem.rss) + ' | acik hesap: ' + oturumlar.size)
    const buyukler = Array.from(harita.entries()).filter(([ad, b]) => ad !== '(kok)' && b >= 1048576).sort((a, b) => b[1] - a[1]).slice(0, 14)
    for (const [ad, b] of buyukler) log('  ' + mbYaz(b).padStart(9) + '  ' + ad)
    if (oncekiDepolama) {
      const artanlar = []
      for (const [ad, b] of harita) {
        const eski = oncekiDepolama.get(ad) || 0
        if (b - eski >= 262144) artanlar.push([ad, b - eski])
      }
      artanlar.sort((a, b) => b[1] - a[1])
      const fark = agac.boyut - (oncekiDepolama.get('(kok)') || 0)
      log('Onceki rapordan beri toplam degisim: ' + (fark >= 0 ? '+' : '') + mbYaz(fark))
      if (artanlar.length) for (const [ad, f] of artanlar.slice(0, 10)) log('  +' + mbYaz(f).padStart(8) + '  ' + ad)
      else log('  (onceki rapordan beri 256 KB ustunde artan klasor yok)')
    } else {
      log('Ilk rapor kaydedildi. Hesap ekleyip calistirdiktan sonra tekrar bas, hangi klasorun buyudugunu gosterir.')
    }
    oncekiDepolama = harita
  } catch (e) {
    log('Depolama raporu hatasi: ' + e.message)
  } finally { depolamaMesgul = false }
}

channel.addListener('depolama', () => { depolamaRaporu() })

// ---------- Arayuzden gelen mesajlar ----------
const adGecerli = (s) => /^[A-Za-z0-9_]{3,16}$/.test(s || '')

channel.addListener('hazir', () => {
  channel.send('gecmis', gunluk.slice())
  durumGonder()
  tgDurumGonder()
  const k = profilOku()
  if (k && k.otomatik && oturumlar.size === 0 && !elleDurduruldu) hepsiniBaslat(k, 'otomatik baslatma')
})

channel.addListener('baslat', (veri) => {
  try {
    veri = veri || {}
    const gelen = Array.isArray(veri.hesaplar) ? veri.hesaplar : []
    if (gelen.length === 0) { channel.send('hata', 'En az bir AFK hesabi ekle.'); return }
    const alici = String(veri.alici || '').trim()
    if (alici && !adGecerli(alici)) { channel.send('hata', 'Dinar alacak hesap adi 3-16 karakter olmali (harf, rakam, alt cizgi). Takas istemiyorsan bos birak.'); return }
    const altin = String(veri.altinHesabi || '').trim()
    if (altin && !adGecerli(altin)) { channel.send('hata', 'Altin hesabi adi 3-16 karakter olmali (harf, rakam, alt cizgi). Kullanmayacaksan bos birak.'); return }
    const kayit = profilOku()
    const kayitliSifre = (ad) => {
      const h = kayit && kayit.hesaplar.find((x) => x.kullanici.toLowerCase() === ad.toLowerCase())
      return h ? h.sifre : ''
    }
    const gorulen = new Set()
    const hesaplar = []
    for (const h of gelen) {
      const ad = String((h && h.kullanici) || '').trim()
      if (!adGecerli(ad)) { channel.send('hata', '"' + ad + '" gecerli bir hesap adi degil (3-16 karakter, harf, rakam, alt cizgi).'); return }
      if (gorulen.has(ad.toLowerCase())) { channel.send('hata', ad + ' hesabi birden fazla kez eklenmis.'); return }
      if (alici && ad.toLowerCase() === alici.toLowerCase()) { channel.send('hata', 'Dinar alacak hesap (' + ad + ') AFK hesaplarindan biri olamaz.'); return }
      let sifre = String((h && h.sifre) || '')
      if (!sifre) sifre = kayitliSifre(ad)
      if (!sifre) { channel.send('hata', ad + ' icin sifre girilmeli.'); return }
      if (sifre.length > 64 || /\s/.test(sifre)) { channel.send('hata', ad + ' sifresi bosluk icermemeli ve en fazla 64 karakter olmali.'); return }
      gorulen.add(ad.toLowerCase())
      hesaplar.push({ kullanici: ad, sifre })
    }
    altinAyar = altin
    const profil = { alici, altinHesabi: altin, otomatik: !!veri.otomatik, hesaplar }
    profilKaydet(profil)
    elleDurduruldu = false
    hepsiniBaslat(profil, 'elle')
  } catch (e) { channel.send('hata', 'Baslatilamadi: ' + e.message) }
})

// Arayuzden bir AFK hesabinin sohbetine yazi / komut gonder
channel.addListener('sohbet', (veri) => {
  try {
    veri = veri || {}
    const ad = String(veri.kullanici || '').trim().toLowerCase()
    const mesaj = String(veri.mesaj || '').replace(/[\r\n\u0000-\u001f]/g, ' ').trim().slice(0, 256)
    if (!mesaj) return
    const s = oturumlar.get(ad)
    if (!s) { log('Mesaj gonderilemedi: ' + (veri.kullanici || '?') + ' hesabi calismiyor'); return }
    if (!s.bot || !canli(s, s.bot)) { log('Mesaj gonderilemedi: bot sunucuda degil', s); return }
    s.sohbetDinleBitis = Date.now() + 8000   // cevabi gunluge yaz
    s.bot.chat(mesaj)
    log('Gonderildi: ' + (/^\/(login|l|register|reg|changepassword|cp)\b/i.test(mesaj) ? mesaj.split(/\s+/)[0] + ' ***' : mesaj), s)
  } catch (e) { log('Mesaj gonderilemedi: ' + e.message) }
})

// ---------- Altin hesabi: her 5 sn'de /dctakas, /actakas yaz ve envanterdeki altin cevherlerini (gold_ore) yere at ----------
let altinAyar = null   // arayuzden girilen hesap adi (null: kayitli profildekini kullan)
function altinHesabiAl() {
  if (altinAyar !== null) return altinAyar
  const k = profilOku()
  return (k && k.altinHesabi) || ''
}

// Envanterdeki butun gold_ore yiginlarini Q (drop) ile ileriye firlatir, atilan toplam adedi dondurur
async function altinAt(s, bot) {
  let adet = 0
  const yiginlar = bot.inventory.items().filter((it) => it.name === A.ALTIN_ESYA)
  if (!yiginlar.length) return 0
  // Esya baktigin yone dogru atilir: once ufka bak (yere bakiyorsa dibine duser), yaw'i oldugu gibi birak
  try { await bot.look(bot.entity.yaw, A.ALTIN_BAKIS_PITCH, true) } catch (e) {}
  await bekle(100)
  for (const it of yiginlar) {
    if (!canli(s, bot)) break
    try {
      // Q tusu: mode 4 (drop), button 1 = Ctrl+Q (tum yigin), button 0 = tek adet
      await bot.clickWindow(it.slot, 1, 4)
      adet += it.count
    } catch (e) {
      // Q tiklamasi olmazsa eski yonteme dus
      try { await bot.tossStack(it); adet += it.count } catch (e2) { log('Altin cevheri atilamadi: ' + e2.message, s); break }
    }
    await bekle(A.ALTIN_ATMA_ARA)
  }
  return adet
}

let altinMesgul = false
async function altinDongu() {
  if (altinMesgul) return
  const ad = altinHesabiAl().toLowerCase()
  if (!ad) return
  const s = oturumlar.get(ad)
  if (!s || !s.calisiyor || s.cikarildi || !s.bot) return
  const bot = s.bot
  if (!canli(s, bot)) return
  if (!s.altinHazir) return   // /login + oyun komutu bitmeden baslama
  if (s.tradeMesgul || s.odulMesgul || s.depoMesgul) return   // menu / trade islemi surerken araya girme
  altinMesgul = true
  try {
    for (let i = 0; i < A.ALTIN_KOMUTLAR.length; i++) {
      if (!canli(s, bot)) return
      bot.chat(A.ALTIN_KOMUTLAR[i])
      await bekle(A.ALTIN_KOMUT_ARA)
    }
    if (!canli(s, bot)) return
    const adet = await altinAt(s, bot)
    if (adet) log('Yere atildi: ' + adet + ' adet ' + A.ALTIN_ESYA, s)
  } catch (e) { log('Altin dongusu hatasi: ' + e.message, s) }
  finally { altinMesgul = false }
}
setInterval(altinDongu, A.ALTIN_ARALIK)

channel.addListener('altinHesabi', (veri) => {
  try {
    const ad = String((veri && veri.kullanici) || '').trim()
    if (ad && !adGecerli(ad)) { channel.send('hata', 'Altin hesabi adi 3-16 karakter olmali (harf, rakam, alt cizgi). Kullanmayacaksan bos birak.'); return }
    const eski = altinHesabiAl().toLowerCase()
    altinAyar = ad
    const k = profilOku()
    if (k) profilKaydet({ ...k, altinHesabi: ad })
    // bagli hesaplarin akisini yeni ayara gore yeniden calistir (eski altin hesabi AFK'ya doner, yeni olan AFK'ya gitmeden kalir)
    const yenidenAkis = (anahtar) => {
      const s = oturumlar.get(anahtar)
      if (!s || !s.calisiyor || s.cikarildi || !s.bot || !canli(s, s.bot)) return
      s.sonAkisZamani = 0
      girisSirasiIste(s, () => prisonAkisi(s, s.bot, 'altin ayari'))
    }
    if (eski && eski !== ad.toLowerCase()) { const e = oturumlar.get(eski); if (e && e.altinHazir) yenidenAkis(eski) }
    if (ad) { const y = oturumlar.get(ad.toLowerCase()); if (y && !y.altinHazir) yenidenAkis(ad.toLowerCase()) }
    log(ad ? 'Altin hesabi: ' + ad + ' (oyundayken her ' + Math.round(A.ALTIN_ARALIK / 1000) + ' sn ' + A.ALTIN_KOMUTLAR.join(' + ') + ' yazilir, ' + A.ALTIN_ESYA + ' atilir)' : 'Altin hesabi kapatildi')
    durumGonder()
  } catch (e) { log('Altin hesabi ayarlanamadi: ' + e.message) }
})

// ---------- Hesabi elle oyundan cikar / oyuna sok (program calisirken, hesap bazinda) ----------
// Cikarilan hesap oturumda kalir ama baglantisi kapatilir ve yeniden baglanmaz; "sok" deyince giris sirasina girip bastan girer.
function hesapOyundanCikar(s) {
  if (!s || s.cikarildi) return
  s.cikarildi = true
  clearTimeout(s.timer)
  s.timer = null
  girisSirasindanCikar(s)   // kuyruktaysa cikar, siradaki aktif hesapsa sirayi ilerlet
  const bot = s.bot
  s.bot = null              // 'end' olayi bu yuzden yeniden baglanma baslatmaz, bekleyen islemler canli() ile durur
  s.girisYapildi = false
  s.afkta = false
  s.altinHazir = false
  s.asama = 'Oyundan cikarildi'
  try { if (bot) bot.quit() } catch (e) {}
  log('Oyundan cikarildi (elle)', s)
  bildir('durum', s, 'ℹ️ Oyundan çıkarıldı (elle)')
  durumGonder()
}

function hesapOyunaSok(s) {
  if (!s || !s.cikarildi) return
  s.cikarildi = false
  s.sebepler = []
  log('Oyuna sokuluyor (elle)', s)
  bildir('durum', s, 'ℹ️ Oyuna sokuluyor (elle)')
  asamaYaz(s, 'Sirada')
  baglan(s)                 // giris sirasina girer, sirasi gelince baglanip normal akisi calistirir
}

channel.addListener('oyun', (veri) => {
  try {
    veri = veri || {}
    const ad = String(veri.kullanici || '').trim().toLowerCase()
    const s = oturumlar.get(ad)
    if (!s || !s.calisiyor) { log('Islem yapilamadi: ' + (veri.kullanici || '?') + ' hesabi calismiyor (once Baslat)'); return }
    if (veri.islem === 'cikar') hesapOyundanCikar(s)
    else if (veri.islem === 'sok') hesapOyunaSok(s)
  } catch (e) { log('Oyun islemi hatasi: ' + e.message) }
})

channel.addListener('durdur', () => { elleDurduruldu = true; hepsiniDurdur('elle') })

channel.addListener('trade', () => {
  if (oturumlar.size === 0) { log('Dinar gonderimi icin once hesaplari baslat'); return }
  if (!Array.from(oturumlar.values()).some((x) => x.profil.alici)) { log('Dinar alacak hesap girilmemis, takas yapilmaz'); return }
  for (const s of oturumlar.values()) if (s.bot) tradeIste(s, s.bot, 'elle')
})

channel.addListener('skor', () => {
  if (oturumlar.size === 0) { log('Skor tablosu icin once hesaplari baslat'); return }
  for (const s of oturumlar.values()) skorYazdir(s)
})

channel.addListener('sil', () => {
  elleDurduruldu = true
  hepsiniDurdur('kayitlar siliniyor')
  profilSil()
  altinAyar = ''
  tgSil()
  log('Kayitli bilgiler silindi (Telegram ayarlari dahil)')
  durumGonder()
  tgDurumGonder()
})

// nodejs-mobile'da yakalanmayan hata calisma ortamini kapatir ve yeniden baslatilamaz; bu yuzden yut ve yaz
process.on('uncaughtException', (e) => { log('Beklenmeyen hata: ' + (e && e.message)) })
process.on('unhandledRejection', (e) => { log('Beklenmeyen hata: ' + (e && e.message ? e.message : e)) })

log('AFK Bot hazir')
