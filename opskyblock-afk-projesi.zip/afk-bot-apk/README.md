# AFK Rone OpSkyblock

OpSkyblock sunucusunda (play.ronemacraft.com) hesapları sırayla sokup AFK bekleten Android uygulaması. GenPvP uygulamasıyla aynı altyapıdır; farklı paket adı (`com.shibabey.roneopskyblock`) kullandığı için ikisi aynı telefonda aynı anda kurulu kalıp çalışabilir.

## Akış (her hesap, sırayla)

1. Sunucuya girer, `/login` gönderir.
2. 10 saniye sonra `/opskyblock` yazar.
3. 10 saniye sonra `/warp afk` yazar ve orada bekler.
4. Sıradaki hesap ancak bu hesabın işleri bitince (ya da bağlantısı kopunca / `SIRA_ZAMAN_ASIMI` dolunca) bağlanır.

## Dinar gönderme

Uygulamada **Dinar alacak hesap** girilmişse, o hesap AFK hesaplarına özel mesajla “trade” yazdığında (ya da **Dinarı şimdi gönder** düğmesine basınca) her hesap sırayla:

1. `/bal` yazıp cevaptaki bakiyeyi okur (`1.250`, `1,234.56`, `1.2M` gibi biçimleri tanır),
2. bütün parayı `/pay <alıcı> <miktar>` ile gönderir (ondalık kısım aşağı yuvarlanır, `DINAR_ONDALIK` ile değiştirilir).

Alıcı hesap boşsa dinar gönderimi ve trade yapılmaz.

## Trade başlat

GenPvP uygulamasındakiyle aynıdır: `/tpa` (10 sn içinde kabul edilmezse iptal), `/trade`, sadece `trail_key` / `trial_key` eşyalarını trade ekranına koyma, 0. slottaki onay düğmesi, 6 saniye sonra `/warp afk`.

## Ayarlar

`node-kaynak/index.js` başında: `OYUN_KOMUTU`, `BAL_KOMUTU`, `PAY_KOMUTU`, `BAL_ESLESME`, `DINAR_ONDALIK`, `ETIKET` (Telegram mesajlarının başına eklenir), bekleme süreleri, `GUNLUK_ACIK` (bu uygulamada kapalı).

## Telegram

Ayarlar her uygulamada ayrıdır. İki uygulama aynı botu kullanırsa mesajların başında `[OpSkyblock]` etiketi görünür.
