# OpSkyblock Afk 2

OpSkyblock sunucusunda (play.ronemacraft.com) hesapları sırayla sokup AFK bekleten Android uygulaması. GenPvP uygulamasıyla aynı altyapıdır; farklı paket adı (`com.shibabey.roneopskyblock`) kullandığı için ikisi aynı telefonda aynı anda kurulu kalıp çalışabilir.

## Akış (her hesap, sırayla)

1. Sunucuya girer, `/login` gönderir.
2. 10 saniye sonra `/opskyblock` yazar.
3. 10 saniye sonra `/warp afk` yazar ve orada bekler. Sohbette “dünya oyuncu limitine ulaştı” uyarısı gelirse sırayla `/warp afk2` ve `/warp afk3` dener. Üçü de doluysa 20 saniye sonra bastan dener (en fazla 5 tur), olmazsa vazgeçip sıradaki hesaba geçer.
4. Sıradaki hesap ancak bu hesabın işleri bitince (ya da bağlantısı kopunca / `SIRA_ZAMAN_ASIMI` dolunca) bağlanır.

## Dinar gönderme

Uygulamada **Dinar alacak hesap** girilmişse, o hesap AFK hesaplarına özel mesajla “trade” yazdığında (ya da **Dinarı şimdi gönder** düğmesine basınca) her hesap sırayla:

1. `/bal` yazıp cevaptaki bakiyeyi okur (`1.250`, `1,234.56`, `1.2M` gibi biçimleri tanır),
2. bütün parayı `/pay <alıcı> <miktar>` ile gönderir (ondalık kısım aşağı yuvarlanır, `DINAR_ONDALIK` ile değiştirilir).

Alıcı hesap boşsa dinar gönderimi ve trade yapılmaz.

## Trade başlat

GenPvP uygulamasındakiyle aynıdır: `/tpa` (10 sn içinde kabul edilmezse iptal), `/trade`, sadece `trail_key` / `trial_key` eşyalarını trade ekranına koyma, 0. slottaki onay düğmesi, 6 saniye sonra `/warp afk`.

## Ayarlar

`node-kaynak/index.js` başında: `OYUN_KOMUTU`, `BAL_KOMUTU`, `PAY_KOMUTU`, `BAL_ESLESME`, `DINAR_ONDALIK`, `ETIKET` (Telegram mesajlarının başına eklenir), bekleme süreleri, `GUNLUK_*` (günlük ödül).

## Telegram

Ayarlar her uygulamada ayrıdır. İki uygulama aynı botu kullanırsa mesajların başında `[OpSkyblock]` etiketi görünür.


## Günlük ödül

GenPvP uygulamasıyla aynı mantık: bot her başladığında yerel tarih/saati günlüğe yazar, hesap başına son alınan ödül tarihini saklar, AFK noktasına varınca ve her gün gece yarısı bugünün ödülü alınmamışsa `/günlüködül` (olmazsa `/gunlukodul`) yazıp menüdeki **ender chest**'e tıklar. Yeşil blok = alınmış. Menü GenPvP'dekiyle aynıdır: 2. satırdaki 10-16. slotlar 1-7. günleri gösterir (yeşil blok = alınmış, ender chest = alınabilir, en soldaki sandığa tıklanır). Slotlar `GUNLUK_SLOTLAR` ile değişir; bu aralıkta ne ender chest ne yeşil blok bulunursa menü tanınmadı sayılır ve ödül alındı diye kaydedilmez. Telegram'da **Günlük ödül** olayı vardır.


## Ada sandığı (spawner / anahtar / etkinlik kemiği)

AFK'daki her hesabın envanteri **dakikada bir** kontrol edilir (AFK noktasına varıldıktan 1 dakika sonra ilk kontrol). Envanterde `spawner`, `trail_key` / `trial_key` ya da her akşam 20:00 etkinliğinden gelen **Kurt Etkinlik Kemiği** (özel isimli `bone`; sıradan kemiğe dokunulmaz) varsa `/is chest` yazılır, açılan **Ada Sandığı** menüsünde **1. sandığa** tıklanır ve eşyalar shift+tıkla ile içine konur. Sandık dolarsa menü yeniden açılıp sıradaki sandığa geçilir. Toplam **21 sandık** denenir (menüde 10-16, 19-25 ve 28-34. slotlar). Hepsi doluysa kalan eşya envanterde bırakılır ve günlüğe / Telegram'a yazılır. Dolu çıkan sandık 30 dakika boyunca tekrar denenmez, böylece her dakika 21 sandık gezilmez. Hesaplar sırayla sandığa gider. Ayarlar `DEPO_*` ile başlar.

**Eşyaları sandığa koy** düğmesi aynı işi hemen yapar, **Günlük ödülü şimdi al** düğmesi her hesap için günlük ödül menüsüne bakıp alınabilir ödül varsa alır.


Günlük ödülde günlüğe sadece sonuç yazılır: `Ödül alındı: <ödüller>` ya da `Ödül alınamadı: <sebep>`. Menü pencerelerinin içeriği (günlük ödül, ada sandığı, beacon) günlüğe yazdırılmaz. Trade ekranının dökümü (`Trade ekrani acildi ... Dolu slotlar`) yazılır, ama adında `glass` geçen dolgu eşyaları (`TRADE_DOKUM_GIZLE`) gösterilmez.


## Hesabı oyundan çıkar / oyuna sok

Program çalışırken her hesap satırında **Oyundan çıkar** düğmesi vardır. Basınca o hesabın sunucu bağlantısı kapatılır, yeniden bağlanma denenmez, giriş sırasından ve otomatik işlerden (günlük ödül, sandık, trade, zamanlayıcı) çıkarılır; durumu **Oyundan çıkarıldı** olarak görünür. Düğme **Oyuna sok**'a döner. Ona basınca hesap giriş sırasına girer ve sırası gelince baştan girip normal akışı çalıştırır. Diğer hesaplar bundan etkilenmez. **Durdur**'a basmak hepsini kapatır, uygulama yeniden açılınca çıkarılmış hesap da normal şekilde girer (çıkarma durumu kaydedilmez).


## Uygulama ikonu

İkon dosyaları `android-ekler/ikon/` içindedir (`mipmap-*` klasörleri + 512 px kaynak `ikon-512.png`). `npm run android:ekle` çalışınca `scripts/android-kur.mjs` bunları Android projesine kopyalar ve varsayılan adaptif ikon tanımlarını siler. İkonu değiştirmek için bu klasördeki PNG'leri aynı adlarla değiştir.

## Oy hatırlatması (TopG)

Sunucunun TopG sayfasındaki oy formu Cloudflare doğrulaması istediği için oy **otomatik gönderilmez**; bot sadece hatırlatır. Hesaplar çalışırken her 6 saatte bir (TopG'nin oy aralığı) Telegram'a ve günlüğe oy linkiyle birlikte çalışan hesapların listesi yazılır. Oyu her hesap adıyla linkten elle verirsin. Son hatırlatma zamanı şifreli dosyada saklanır, uygulama yeniden açılınca hemen tekrar etmez. Telegram'daki **Oy hatırlatması** kutusuyla açılıp kapanır. Ayarlar `node-kaynak/index.js` başında `OY_ACIK`, `OY_URL`, `OY_ARALIK`.

## Atma hesapları (4 yuva)

Arayüzde 4 atma hesabı kutusu var, hepsi isteğe bağlı ve hesap adı AFK hesapları listesindeki bir hesap olmalı:

- **Altın cevheri atacak 1. ve 2. hesap (`/actakas`)**: oyundayken her 5 saniyede bir sadece `/actakas` yazar, envanterdeki bütün `gold_ore` yığınlarını yere atar.
- **Demir cevheri atacak 1. ve 2. hesap (`/dctakas`)**: oyundayken her 5 saniyede bir sadece `/dctakas` yazar, envanterdeki bütün `iron_ore` yığınlarını yere atar.

Atma hesapları AFK bölgesine gitmez; günlük ödül (gece 00.00) ve `/is chest` yine yapılır. Bir hesap yalnızca tek yuvada olabilir. Bot çalışırken de yuva değiştirilebilir: adı yazıp o yuvanın **Uygula** düğmesine basılır, boş bırakıp Uygula kapatır. Ayarlar kayıtlı profille saklanır. Komut, eşya ve aralık değerleri `node-kaynak/index.js` başında `ALTIN_KOMUT_1` (1. ve 3. yuva), `ALTIN_KOMUT_2` (2. ve 4. yuva), `ALTIN_ESYA`, `DEMIR_ESYA`, `ALTIN_ARALIK`.

Atma, **MCC'nin `DropItem` komutu gibi** envanter penceresinden Q tıklamasıyla (`ALTIN_ATMA_YONTEM: 'pencere'`) yapılır; bot bakışına hiç dokunmaz (`ALTIN_BAKIS_PITCH: null`), yani eşya botun oyuna girdiği yöne doğru gider. Sunucu bu yöntemle farklı davranıyorsa `'paket'` (oyundaki Q tuşu paketi) denenebilir. Eğim için `ALTIN_BAKIS_PITCH` (0 = yatay, pozitif = yukarı, negatif = aşağı), yakındaki huniye hesaplı atış için `ALTIN_NISAN: true` kullanılır. Log'daki `Tani` satırı eşyanın huninin ortasına kaç blok uzağa düştüğünü yazar. Huni saniyede yaklaşık 2,5 eşya taşır ve 5 slotluk (320 adet) tamponu vardır; sandığı huninin altına ya da yanına bağlamazsan taşan eşya yerde kalır.

## Eski uygulamayla yan yana kurulum

Bu sürüm farklı paket adı kullanır: `com.shibabey.roneopskyblockproxy` (eski sürüm `com.shibabey.roneopskyblock`; paket adındaki "proxy" yalnızca teknik bir kimliktir, uygulamada proxy özelliği yoktur). Android bunları iki ayrı uygulama sayar, yani eskisini silmeden ikisi aynı telefonda kurulu kalır. Uygulama adı **OpSkyblock Afk 2**, Telegram etiketi `[OpSkyblock 2]`. Verileri (hesaplar, Telegram ayarları) ayrıdır, eski uygulamadan otomatik aktarılmaz; yeni uygulamaya bir kez elle girilir. Aynı hesabı iki uygulamada birden çalıştırma: sunucu birini atar. Paket adını değiştirmek için `capacitor.config.json` içindeki `appId` düzenlenir.
