# OpSkyblock Afk

OpSkyblock sunucusunda (play.ronemacraft.com) hesapları sırayla sokup AFK bekleten Android uygulaması. GenPvP uygulamasıyla aynı altyapıdır; farklı paket adı (`com.shibabey.roneopskyblock`) kullandığı için ikisi aynı telefonda aynı anda kurulu kalıp çalışabilir.

## Akış (her hesap, sırayla)

1. Sunucuya girer, `/login` gönderir.
2. 10 saniye sonra `/opskyblock` yazar.
3. 10 saniye sonra `/warp afk` yazar ve orada bekler. Sohbette “dünya oyuncu limitine ulaştı” uyarısı gelirse sırayla `/warp afk2` ve `/warp afk3` dener. Üçü de doluysa 20 saniye sonra bastan dener (en fazla 5 tur), olmazsa vazgeçip sıradaki hesaba geçer.
4. Sıradaki hesap ancak bu hesabın işleri bitince (ya da bağlantısı kopunca / `SIRA_ZAMAN_ASIMI` dolunca) bağlanır.

## Dinar gönderme

Uygulamada **Dinar alacak hesap** girilmişse, o hesap AFK hesaplarına özel mesajla “trade” yazdığında (ya da **Dinarı şimdi gönder** düğmesine basınca) her hesap sırayla:

1. `/bal` yazıp cevaptaki bakiyeyi okur (`1.250`, `1,234.56`, `1.2M` gibi biçimleri tanır),
2. bütün parayı `/pay <alıcı> <miktar>` ile gönderir (ondalık kısım aşağı yuvarlanır, `DINAR_ONDALIK` ile değiştirilir).

Alıcı hesap boşsa dinar gönderimi ve trade yapılmaz.

## Trade başlat

GenPvP uygulamasındakiyle aynıdır: `/tpa` (10 sn içinde kabul edilmezse iptal), `/trade`, sadece `trail_key` / `trial_key` eşyalarını trade ekranına koyma, 0. slottaki onay düğmesi, 6 saniye sonra `/warp afk`.

## Ayarlar

`node-kaynak/index.js` başında: `OYUN_KOMUTU`, `BAL_KOMUTU`, `PAY_KOMUTU`, `BAL_ESLESME`, `DINAR_ONDALIK`, `ETIKET` (Telegram mesajlarının başına eklenir), bekleme süreleri, `GUNLUK_*` (günlük ödül).

## Telegram

Ayarlar her uygulamada ayrıdır. İki uygulama aynı botu kullanırsa mesajların başında `[OpSkyblock]` etiketi görünür.


## Günlük ödül

GenPvP uygulamasıyla aynı mantık: bot her başladığında yerel tarih/saati günlüğe yazar, hesap başına son alınan ödül tarihini saklar, AFK noktasına varınca ve her gün gece yarısı bugünün ödülü alınmamışsa `/günlüködül` (olmazsa `/gunlukodul`) yazıp menüdeki **ender chest**'e tıklar. Yeşil blok = alınmış. Menü GenPvP'dekiyle aynıdır: 2. satırdaki 10-16. slotlar 1-7. günleri gösterir (yeşil blok = alınmış, ender chest = alınabilir, en soldaki sandığa tıklanır). Slotlar `GUNLUK_SLOTLAR` ile değişir; bu aralıkta ne ender chest ne yeşil blok bulunursa menü tanınmadı sayılır ve ödül alındı diye kaydedilmez. Telegram'da **Günlük ödül** olayı vardır.


## Ada sandığı (spawner / anahtar / etkinlik kemiği)

AFK'daki her hesabın envanteri **dakikada bir** kontrol edilir (AFK noktasına varıldıktan 1 dakika sonra ilk kontrol). Envanterde `spawner`, `trail_key` / `trial_key` ya da her akşam 20:00 etkinliğinden gelen **Kurt Etkinlik Kemiği** (özel isimli `bone`; sıradan kemiğe dokunulmaz) varsa `/is chest` yazılır, açılan **Ada Sandığı** menüsünde **1. sandığa** tıklanır ve eşyalar shift+tıkla ile içine konur. Sandık dolarsa menü yeniden açılıp sıradaki sandığa geçilir. Toplam **21 sandık** denenir (menüde 10-16, 19-25 ve 28-34. slotlar). Hepsi doluysa kalan eşya envanterde bırakılır ve günlüğe / Telegram'a yazılır. Dolu çıkan sandık 30 dakika boyunca tekrar denenmez, böylece her dakika 21 sandık gezilmez. Hesaplar sırayla sandığa gider. Ayarlar `DEPO_*` ile başlar.

**Eşyaları sandığa koy** düğmesi aynı işi hemen yapar, **Günlük ödülü şimdi al** düğmesi her hesap için günlük ödül menüsüne bakıp alınabilir ödül varsa alır.


Günlük ödülde günlüğe sadece sonuç yazılır: `Ödül alındı: <ödüller>` ya da `Ödül alınamadı: <sebep>`. Menü pencerelerinin içeriği (günlük ödül, ada sandığı, beacon) günlüğe yazdırılmaz. Trade ekranının dökümü (`Trade ekrani acildi ... Dolu slotlar`) yazılır, ama adında `glass` geçen dolgu eşyaları (`TRADE_DOKUM_GIZLE`) gösterilmez.


## Hesabı oyundan çıkar / oyuna sok

Program çalışırken her hesap satırında **Oyundan çıkar** düğmesi vardır. Basınca o hesabın sunucu bağlantısı kapatılır, yeniden bağlanma denenmez, giriş sırasından ve otomatik işlerden (günlük ödül, sandık, trade, zamanlayıcı) çıkarılır; durumu **Oyundan çıkarıldı** olarak görünür. Düğme **Oyuna sok**'a döner. Ona basınca hesap giriş sırasına girer ve sırası gelince baştan girip normal akışı çalıştırır. Diğer hesaplar bundan etkilenmez. **Durdur**'a basmak hepsini kapatır, uygulama yeniden açılınca çıkarılmış hesap da normal şekilde girer (çıkarma durumu kaydedilmez).


## Altın cevheri atma hesabı

Arayüzde **Altın cevheri atacak hesap** kutusuna bir hesap adı yazılırsa, o hesap `/login` ve `/opskyblock` ile oyuna girer ama **AFK bölgesine gitmez** (günlük ödül ve `/is chest` ile ada sandığına eşya koyma yine çalışır: girişte ve her gece 00.00'da ödül alınır, envanter dakikada bir kontrol edilir; trade işlemleri bu hesapta yapılmaz çünkü sonunda `/warp afk` ile AFK'ya dönülür). Oyundayken her **5 saniyede bir** sırayla `/dctakas`, `/actakas` yazar ve envanterindeki bütün `gold_ore` yığınlarını önce yatay bakıp **Q (drop) ile ileriye fırlatır**. Hesap bağlı değilse, çıkarılmışsa ya da trade işlemi sürüyorsa o tur atlanır. Bot çalışırken de kutuya yazıp **Uygula**'ya basarak değiştirilir ya da boş bırakılıp kapatılır; ayar kaydedilir. Bağlı hesaplar için değişiklik hemen uygulanır: yeni hesap AFK'ya gitmeden kalır, eski altın hesabı normal akışla AFK'ya döner. Ayarlar `node-kaynak/index.js` başında `ALTIN_*` ile başlar.

Bot atarken bakışına hiç dokunmaz: altın cevherleri botun o an baktığı yöne fırlar. Bakış yönünü sen ayarlarsın, huniyi düştükleri yere koy. Huni saniyede yaklaşık 2,5 eşya taşır ve 5 slotluk (320 adet) tamponu vardır; sandığı huninin altına ya da yanına bağlamazsan taşan altın yerde kalır.

## Uygulama ikonu

İkon dosyaları `android-ekler/ikon/` içindedir (`mipmap-*` klasörleri + 512 px kaynak `ikon-512.png`). `npm run android:ekle` çalışınca `scripts/android-kur.mjs` bunları Android projesine kopyalar ve varsayılan adaptif ikon tanımlarını siler. İkonu değiştirmek için bu klasördeki PNG'leri aynı adlarla değiştir.
